// Stage11: verified four-page UI plus fresh NTP Hong Kong date/day transitions.
// No fake date before sync; missing day clears old verse without stopping UI.
// Read bounded SD font cache and one verse, unmount SD, then reuse VSPI for touch.
#include <Arduino.h>
#include <SD.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <XPT2046_Touchscreen.h>
#include "touch_gesture.h"
#include <esp_heap_caps.h>
#include "board_config.h"
#include "page_controller.h"
#include "ui_data.h"
#include "font_meta.h"
#include "verse_reader.h"
#include "daily_reader.h"
#include "clock_service.h"
#include "date_transition.h"
#include "web_config.h"
#include "weather_service.h"
#if !defined(ILI9341_2_DRIVER) || !defined(USE_HSPI_PORT) || !defined(SMOOTH_FONT)
#error "Keep verified ILI9341_2_DRIVER, HSPI and SMOOTH_FONT setup."
#endif
static_assert(TFT_MOSI==board_config::LCD_MOSI && TFT_MISO==board_config::LCD_MISO && TFT_SCLK==board_config::LCD_SCLK && TFT_CS==board_config::LCD_CS && TFT_DC==board_config::LCD_DC,"LCD pin map must not change");
TFT_eSPI lcd;
SPIClass sharedSpi(VSPI);
XPT2046_Touchscreen touch(board_config::TOUCH_CS);
TouchGesture gesture;
bool touchStarted=false;
uint32_t lastPoll=0,maxPollGap=0;
uint8_t *fontCache=nullptr;
uint8_t *cachedFont[4]={nullptr,nullptr,nullptr,nullptr};
PageController pages;
bool running=false;
uint8_t activeFont=0;
enum class ContentState {Waiting,Available,Missing,Error};
ClockService networkClock;
WebConfig webConfig;
WeatherService weatherService;
uint32_t lastWeatherSequence=0,lastWeatherMinute=0;
String lastWebFooter;
uint32_t lastWebCheck=0;
DateTransition dayTransition;
bool testDateMode=false;daily::Date testDate;
const char *lastClockLabel="";
uint32_t lastDateCheck=0;
struct DailyContent {
  ContentState state=ContentState::Waiting;
  daily::Date date;daily::Reference ref;
  char verse[board_config::VERSE_BUFFER_BYTES]={};
  char lines[2][128]={};char dateText[11]={},weekdayText[80]={},referenceText[80]={};
};
DailyContent current;
const BibleBook *knownBook(const char *code);
#include "home_marquee.h"
HomeMarquee homeMarquee(&lcd);
#include "reflection_question.h"
ReflectionQuestion reflectionQuestion;
const char *dateModeLabel() {return testDateMode?"測試日期":networkClock.label();}
void dateLabels(DailyContent &data) {
  snprintf(data.dateText,sizeof(data.dateText),"%04u/%02u/%02u",data.date.year,data.date.month,data.date.day);
  const char *weekdays[]={"日","一","二","三","四","五","六"};
  snprintf(data.weekdayText,sizeof(data.weekdayText),"星期%s",weekdays[daily::weekday(data.date)]);
}
void unavailableContent(DailyContent &data) {
  data.ref={};data.verse[0]=0;data.lines[1][0]=0;
  snprintf(data.lines[0],sizeof(data.lines[0]),"%s",data.state==ContentState::Missing?"今日未有金句":"經文資料未能讀取");
  snprintf(data.referenceText,sizeof(data.referenceText),"%s",data.state==ContentState::Missing?"SD 尚未提供當日資料":"檢查 SD 卡內容");
}
bool dateError=false;
char serialCommand[32]={};size_t commandLength=0;bool commandOverflow=false;

class ChapterReader {
 public:
  explicit ChapterReader(File &f):file(f),started(millis()) {}
  int read() {
    if(position>=count) {
      yield(); if(millis()-started>=15000) return -2;
      int received=file.read(buffer,sizeof(buffer));
      if(received<0) return -2;
      if(received==0) return file.position()<file.size() ? -2 : -1;
      position=0;count=received;
    }
    return buffer[position++];
  }
 private:
  File &file;uint32_t started;uint8_t buffer[512];size_t position=0,count=0;
};
void heapSample(const char *phase) {
  Serial.printf("HEAP %s free=%u minimum=%u largest=%u bytes\n",phase,unsigned(ESP.getFreeHeap()),unsigned(ESP.getMinFreeHeap()),unsigned(heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)));
}
bool readInt(File &f,int32_t &out) {
  uint8_t b[4];if(f.read(b,4)!=4) return false;
  out=static_cast<int32_t>((uint32_t(b[0])<<24)|(uint32_t(b[1])<<16)|(uint32_t(b[2])<<8)|b[3]);return true;
}
bool validateFont(const UiFontAsset &asset) {
  File f=SD.open(asset.path,FILE_READ);
  if(!f || f.isDirectory() || f.size()!=asset.bytes) {f.close();return false;}
  int32_t h[6];for(auto &v:h) if(!readInt(f,v)) {f.close();return false;}
  if(h[0]!=asset.glyphs || h[0]>512 || h[1]!=11 || h[2]!=asset.size || h[4]<=0 || h[4]>64 || h[5]<0 || h[5]>32) {f.close();return false;}
  uint32_t bytes=24+28*h[0];
  for(int i=0;i<h[0];++i) {
    int32_t g[7];for(auto &v:g) if(!readInt(f,v)) {f.close();return false;}
    if(g[0]<33 || g[0]>65535 || g[1]<=0 || g[1]>64 || g[2]<=0 || g[2]>64 || g[3]<=0 || g[3]>64 || g[4]<-64 || g[4]>64 || g[5]<-64 || g[5]>64) {f.close();return false;}
    bytes+=g[1]*g[2];
  }
  bool okay=bytes==asset.bytes;
  Serial.printf("FONT_PREFLIGHT px=%u glyphs=%u bytes=%u valid=%s\n",asset.size,asset.glyphs,unsigned(bytes),okay?"true":"false");f.close();return okay;
}
void stopUi(const char *reason) {
  running=false;touchStarted=false;lcd.unloadFont();activeFont=0;SD.end();sharedSpi.end();
  free(fontCache);fontCache=nullptr;for(auto &ptr:cachedFont) ptr=nullptr;
  Serial.printf("[FAIL] STAGE10 %s; no automatic retry\n",reason);
  lcd.fillScreen(TFT_WHITE);lcd.setTextColor(TFT_BLACK,TFT_WHITE);lcd.setTextFont(2);lcd.setCursor(16,24);lcd.println("Stage10: not ready");lcd.setCursor(16,52);lcd.println(reason);lcd.setCursor(16,84);lcd.println("Check SD files; send u to retry");
}
bool useFont(uint8_t size) {
  if(activeFont==size && lcd.fontLoaded) return true;
  const UiFontAsset *asset=nullptr;
  for(const auto &candidate:UI_FONTS) if(candidate.size==size) asset=&candidate;
  if(!asset || ESP.getFreeHeap()<65536) return false;
  const size_t index=asset-UI_FONTS;
  if(index>=4 || !cachedFont[index]) return false;
  lcd.loadFont(cachedFont[index]);activeFont=size;
  return lcd.fontLoaded && lcd.gUnicode && lcd.gHeight && lcd.gWidth && lcd.gxAdvance && lcd.gdY && lcd.gdX && lcd.gBitmap;
}
// Only the four small UI subsets are cached; full Bible/full CJK are never loaded.
bool cacheFonts() {
  uint32_t total=FONT_SLOT_CAPACITY[0]+FONT_SLOT_CAPACITY[2];
  if(total>board_config::FONT_CACHE_LIMIT || ESP.getFreeHeap()<total+65536 || heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)<total) return false;
  fontCache=static_cast<uint8_t*>(malloc(total));if(!fontCache) return false;
  size_t offset=0;uint32_t started=millis();
  for(size_t index=0;index<4;++index) {
    if(index!=0&&index!=2)continue; // Only Bible 16/24px fonts need heap caching.
    const auto &asset=UI_FONTS[index];File f=SD.open(asset.path,FILE_READ);
    if(!f || f.size()!=asset.bytes) {f.close();return false;}
    cachedFont[index]=fontCache+offset;
    size_t received=0;
    while(received<asset.bytes) {
      if(millis()-started>=15000) {f.close();return false;}
      size_t want=min(size_t(1024),size_t(asset.bytes)-received);
      size_t got=f.read(fontCache+offset+received,want);
      if(got!=want) {f.close();return false;}
      received+=got;yield();
    }
    offset+=FONT_SLOT_CAPACITY[index];f.close();
  }
  Serial.printf("FONT_CACHE bytes=%u limit=%u source=SD embedded=false\n",unsigned(total),unsigned(board_config::FONT_CACHE_LIMIT));
  heapSample("after_font_cache");return true;
}
// All dynamic text comes from the Stage2 validated UTF8 stream parser.
uint32_t nextCodepoint(const char *text,size_t &offset) {
  uint8_t c=static_cast<uint8_t>(text[offset++]);if(c<128) return c;
  unsigned n=c<224?1:(c<240?2:3);uint32_t cp=c&((1u<<(6-n))-1);
  while(n--) cp=(cp<<6)|(static_cast<uint8_t>(text[offset++])&63);return cp;
}
bool covered(const char *text) {
  size_t offset=0;
  while(text[offset]) {
    uint32_t cp=nextCodepoint(text,offset);uint16_t index;
    if(cp==32) continue;
    if(cp>65535 || !lcd.getUnicodeIndex(cp,&index)) {Serial.printf("[FAIL] MISSING_GLYPH U+%04lX\n",static_cast<unsigned long>(cp));return false;}
  }
  return true;
}
const BibleBook *knownBook(const char *code) {
  for(const auto &book:BIBLE_BOOKS) if(strcmp(code,book.code)==0) return &book;
  return nullptr;
}
// SD is mounted and Touch stopped here. Both slots are reserved before Wi-Fi starts.
// Read once into the reserved bounded slot, then validate CRC and structure in RAM.
// The library cannot use the cache until both checks pass; failure stops and frees UI.
bool loadDailyFont(const char *path,uint8_t size,uint32_t bytes,uint32_t expectedCrc,unsigned index) {
  if(index>=4 || bytes>FONT_SLOT_CAPACITY[index] || !cachedFont[index]) return false;
  File f=SD.open(path,FILE_READ);
  if(!f || f.isDirectory() || f.size()!=bytes) {f.close();return false;}
  uint32_t crc=0xffffffffu,started=millis();size_t received=0;
  while(received<bytes) {
    if(millis()-started>=5000) {f.close();return false;}
    size_t want=min(size_t(1024),size_t(bytes)-received);
    size_t got=f.read(cachedFont[index]+received,want);
    if(got!=want) {f.close();return false;}
    for(size_t n=0;n<got;++n) crc=fontmeta::crcByte(crc,cachedFont[index][received+n]);
    received+=got;yield();
  }
  f.close();bool okay=(crc^0xffffffffu)==expectedCrc;
  const bool valid=fontmeta::validFont(cachedFont[index],bytes,size);
  Serial.printf("DAILY_FONT px=%u bytes=%u crc_match=%s slot_capacity=%u structure_valid=%s elapsed_ms=%u\n",size,unsigned(bytes),okay?"true":"false",unsigned(FONT_SLOT_CAPACITY[index]),valid?"true":"false",unsigned(millis()-started));
  return okay && valid;
}
bool loadDailyFonts(DailyContent &candidate) {
  char path[64],line[96]={};
  snprintf(path,sizeof(path),"/fonts/daily/%02u-%02u.meta",candidate.date.month,candidate.date.day);
  File f=SD.open(path,FILE_READ);
  if(!f || f.isDirectory() || f.size()>=sizeof(line)) {f.close();Serial.println("DAILY_FONT_ERROR MISSING_META");return false;}
  size_t length=f.size();bool okay=f.read(reinterpret_cast<uint8_t*>(line),length)==length;f.close();
  if(!okay || !length || line[length-1]!='\n') return false;
  line[--length]=0;if(length && line[length-1]=='\r') line[--length]=0;
  // Embedded control/NUL/newline or unexpected extra rows are rejected.
  for(size_t n=0;n<length;++n) if(line[n]<32 || line[n]>126) return false;
  fontmeta::Metadata meta;
  if(!fontmeta::parse(line,candidate.ref,FONT_SLOT_CAPACITY[0],FONT_SLOT_CAPACITY[2],meta)) {Serial.println("DAILY_FONT_ERROR REF_OR_META_MISMATCH");return false;}
  lcd.unloadFont();activeFont=0;
  snprintf(path,sizeof(path),"/fonts/daily/%02u-%02u_16.vlw",candidate.date.month,candidate.date.day);
  if(!loadDailyFont(path,16,meta.bytes16,meta.crc16,0)) {stopUi("DAILY_FONT16_READ_OR_CRC");return false;}
  snprintf(path,sizeof(path),"/fonts/daily/%02u-%02u_24.vlw",candidate.date.month,candidate.date.day);
  if(!loadDailyFont(path,24,meta.bytes24,meta.crc24,2)) {stopUi("DAILY_FONT24_READ_OR_CRC");return false;}
  return true;
}
bool prepareVerseLines(DailyContent &candidate) {
  candidate.state=ContentState::Error;
  File csv=SD.open(board_config::DAILY_CSV_PATH,FILE_READ);
  if(!csv || csv.isDirectory() || csv.size()>board_config::MAX_CSV_BYTES) {csv.close();Serial.println("DAILY_ERROR CSV_FILE");return false;}
  ChapterReader csvReader(csv);const auto lookup=daily::find(csvReader,candidate.date,candidate.ref,board_config::MAX_CSV_BYTES);csv.close();
  if(lookup!=daily::Status::Found) {candidate.state=lookup==daily::Status::NotFound?ContentState::Missing:ContentState::Error;Serial.printf("DAILY_UNAVAILABLE CSV_STATUS=%u\n",unsigned(lookup));return false;}
  const BibleBook *selectedBook=knownBook(candidate.ref.book);
  if(!selectedBook || candidate.ref.chapter>selectedBook->chapters) {Serial.println("DAILY_ERROR UNKNOWN_BOOK_OR_CHAPTER");return false;}
  char chapterPath[32];snprintf(chapterPath,sizeof(chapterPath),"/bible/%s/%03u.txt",candidate.ref.book,candidate.ref.chapter);
  Serial.printf("DAILY_SELECTED date=%04u-%02u-%02u book=%s chapter=%u verse=%u source=SD_CSV\n",candidate.date.year,candidate.date.month,candidate.date.day,candidate.ref.book,candidate.ref.chapter,candidate.ref.verse);
  File f=SD.open(chapterPath,FILE_READ);
  if(!f || f.isDirectory() || f.size()>board_config::MAX_CHAPTER_BYTES) {f.close();return false;}
  ChapterReader reader(f);auto result=bible_reader::readVerse(reader,uint16_t(candidate.ref.verse),candidate.verse,sizeof(candidate.verse),board_config::MAX_CHAPTER_BYTES);f.close();
  if(result.status!=bible_reader::Status::Found) return false;
  Serial.printf("DAILY_VERSE bytes=%u scanned=%u path=%s\n",unsigned(result.length),unsigned(result.scanned),chapterPath);
  Serial.println("VERSE_BEGIN");Serial.println(candidate.verse);Serial.println("VERSE_END");
  dateLabels(candidate);
  const BibleBook *book=knownBook(candidate.ref.book);
  if(!book || candidate.ref.chapter>book->chapters) {Serial.println("DAILY_ERROR UNKNOWN_BOOK_OR_CHAPTER");return false;}
  snprintf(candidate.referenceText,sizeof(candidate.referenceText),"%s %u:%u · 節錄",book->name,candidate.ref.chapter,candidate.ref.verse);
  if(!loadDailyFonts(candidate)) return false;
  size_t offset=0,chars=0,lastPunctuation=0;
  while(candidate.verse[offset] && chars<23) {
    uint32_t cp=nextCodepoint(candidate.verse,offset);++chars;
    if(cp==0xff0c || cp==0x3002 || cp==0xff1b || cp==0xff01 || cp==0xff1f) lastPunctuation=offset;
  }
  size_t end=lastPunctuation ? lastPunctuation : offset;
  char excerpt[128];if(end+4>=sizeof(excerpt)) return false;
  memcpy(excerpt,candidate.verse,end);excerpt[end]=0;
  if(candidate.verse[end]) strcat(excerpt,"…"); // Visible excerpt label is in UI data.
  if(!useFont(24) || !covered(excerpt)) return false;
  offset=0;size_t start=0,line=0;int width=0;
  while(excerpt[offset]) {
    size_t previous=offset;uint32_t cp=nextCodepoint(excerpt,offset);uint16_t index=0;
    if(cp!=32 && !lcd.getUnicodeIndex(cp,&index)) return false;
    int advance=cp==32?lcd.gFont.spaceWidth:lcd.gxAdvance[index];
    int extent=cp==32?advance:max(advance,int(lcd.gWidth[index])+int(lcd.gdX[index]));
    if(width+extent>288) {
      if(line>=1 || previous==start || previous-start>=sizeof(candidate.lines[0])) return false;
      memcpy(candidate.lines[line],excerpt+start,previous-start);candidate.lines[line++][previous-start]=0;start=previous;width=0;
    }
    width+=advance;
  }
  if(offset-start>=sizeof(candidate.lines[0])) return false;
  memcpy(candidate.lines[line],excerpt+start,offset-start);candidate.lines[line++][offset-start]=0;
  if(line<2) candidate.lines[1][0]=0;
  candidate.state=ContentState::Available;
  Serial.printf("VERSE_EXCERPT source=SD_CSV lines=%u clearly_labelled=true\n",unsigned(line));return true;
}
const char *rowText(const UiRow &row,const DailyContent &data) {
  if(row.source==UiSource::DateMode) return dateModeLabel();
  if(row.source==UiSource::Verse0) return data.lines[0];
  if(row.source==UiSource::Verse1) return data.lines[1];
  if(row.source==UiSource::Date) return data.dateText;
  if(row.source==UiSource::Weekday) return data.weekdayText;
  if(row.source==UiSource::Reference) return data.referenceText;
  return row.text;
}
bool validateCoverage(const DailyContent &data) {
  if(!useFont(24)||!covered(data.lines[0])||!covered(data.lines[1]))return false;
  if(!useFont(16)||!covered(data.referenceText))return false;
  Serial.println("[PASS] BIBLE_GLYPH_COVERAGE");return true;
}
#include "desk_ui.h"
// Everyday pages use the full canvas. Credentials are shown only by drawLanSettings().
void drawStatus() {}
void drawSetupPage() {
  lcd.unloadFont();activeFont=0;lcd.fillScreen(TFT_WHITE);
  lcd.setTextDatum(TL_DATUM);lcd.setTextColor(TFT_BLACK,TFT_WHITE);lcd.setTextWrap(false,false);
  lcd.drawString("Wi-Fi setup",16,8,4);
  lcd.drawFastHLine(16,38,288,lcd.color565(184,184,184));
  lcd.drawString("1. Join this Wi-Fi",16,44,2);
  lcd.drawString(webConfig.ssid(),16,65,4);
  lcd.drawString("Wi-Fi password (10 characters)",16,95,2);
  char password[12];snprintf(password,sizeof(password),"CYD-%s",webConfig.pin());
  lcd.drawString(password,16,115,4);memset(password,0,sizeof(password));
  lcd.drawString("2. Open this address",16,148,2);
  lcd.drawString("http://192.168.4.1/",16,169,2);
  char label[24];snprintf(label,sizeof(label),"Web PIN: %s",webConfig.pin());
  lcd.drawString(label,16,197,2);memset(label,0,sizeof(label));
  lcd.drawString("PIN changes after reboot",16,220,2);
}

void drawPage(const char *trigger) {
 if(webConfig.isAP()){drawSetupPage();pages.drawn(millis());return;}
 uint32_t started=millis();
 if(pages.page()!=0)forecastShowing=false;
 bool refresh=strcmp(trigger,"weather_changed")==0||strcmp(trigger,"extras_changed")==0||strcmp(trigger,"content_refresh")==0||strcmp(trigger,"clock_state_changed")==0||strcmp(trigger,"settings_changed")==0;
 homeMarquee.page(pages.page());
 if(refresh&&pages.page()==0&&!menuShowing&&!settingsShowing&&!forecastShowing){palette();lcd.fillRect(0,0,320,208,canvasBG);drawHome();}else drawDeskPage();drawStatus();
 if(!refresh)pages.drawn(millis());
 if(strcmp(trigger,"content_refresh")!=0){Serial.printf("PAGE_DRAWN page=%u name=%s trigger=%s render_ms=%u hold_ms=%u auto=%s display=%dx%d\n",pages.page()+1,pageNames[pages.page()],trigger,unsigned(millis()-started),unsigned(pages.intervalMs),pages.automatic?"true":"false",lcd.width(),lcd.height());Serial.printf("PAGE_STATE pinned=%s paused=%s touch_poll_max_gap_ms=%u\n",pages.pinned?"true":"false",pages.paused?"true":"false",unsigned(maxPollGap));heapSample("after_page");}
}
bool mountStorage() {
  pinMode(board_config::TOUCH_CS,OUTPUT);digitalWrite(board_config::TOUCH_CS,HIGH);
  if(!sharedSpi.begin(board_config::SD_SCLK,board_config::SD_MISO,board_config::SD_MOSI,board_config::SD_CS)) return false;
  return SD.begin(board_config::SD_CS,sharedSpi,board_config::SD_SPI_HZ,"/sd",4,false);
}
bool startTouchBus() {
  lcd.unloadFont();activeFont=0;SD.end();sharedSpi.end();
  pinMode(board_config::SD_CS,OUTPUT);digitalWrite(board_config::SD_CS,HIGH);
  if(!sharedSpi.begin(board_config::TOUCH_SCLK,board_config::TOUCH_MISO,board_config::TOUCH_MOSI,board_config::TOUCH_CS) || !touch.begin(sharedSpi)) return false;
  touch.setRotation(board_config::RAW_TOUCH_ROTATION);touchStarted=true;gesture=TouchGesture();lastPoll=millis();
  Serial.println("TOUCH_READY R1 calibration=verified_same_board VSPI=touch SD=unmounted IRQ=not_attached");return true;
}
bool readWifiCredentials(wifi_config::Credentials &out) {
  File f=SD.open(board_config::WIFI_PATH,FILE_READ);
  if(!f || f.isDirectory() || f.size()>wifi_config::MAX_BYTES) {f.close();networkClock.status="CONFIG NEEDED OR TOO LARGE";Serial.println("WIFI_CONFIG unavailable; UI remains usable");return false;}
  char buffer[wifi_config::MAX_BYTES+1]={};const size_t bytes=f.size();
  bool readable=f.readBytes(buffer,bytes)==bytes;f.close();
  bool okay=readable && wifi_config::parse(buffer,bytes,out)==wifi_config::Result::Okay;
  memset(buffer,0,sizeof(buffer));
  if(!okay) {networkClock.status="CONFIG INVALID";Serial.println("WIFI_CONFIG invalid; credentials redacted");}
  else Serial.println("WIFI_CONFIG valid; credentials redacted; persistence=RAM_ONLY");
  return okay;
}
void startUi() {
  if(running) return;
  Serial.printf("\n=== CYD Stage13 %s ===\n",board_config::FIRMWARE_VERSION);heapSample("before_start");
  if(!mountStorage()) {stopUi("SD_MOUNT");return;}
  for(const auto &asset:UI_FONTS) if(!validateFont(asset)) {stopUi("CLOCK_FONT_MISSING_OR_INVALID");return;}
  if(!cacheFonts()) {stopUi("FONT_CACHE_READ_OR_MEMORY");return;}
  wifi_config::Credentials credentials;bool configured=WebConfig::load(credentials);
  if(configured) Serial.println("WIFI_CONFIG valid source=NVS credentials=redacted");
  else configured=readWifiCredentials(credentials);
  current=DailyContent();strcpy(current.dateText,"----/--/--");strcpy(current.weekdayText,"日期未設定 · 農曆待補");strcpy(current.lines[0],"等待網絡校時");
  if(!validateCoverage(current)) {stopUi("GLYPH_COVERAGE");return;}
  if(!startTouchBus()) {stopUi("TOUCH_BEGIN");return;}
  pages=PageController();refreshDeskConfig();dayTransition=DateTransition();testDateMode=false;dateError=false;maxPollGap=0;running=true;
  homeMarquee.clear(millis(),"等候每日金句");reflectionQuestion.clear();lastClockLabel=dateModeLabel();drawPage("boot_waiting_for_time");
  if(configured) networkClock.begin(credentials);
  webConfig.begin(configured,credentials);
  if(!weatherService.begin()) Serial.println("WEATHER task_start=FAIL");
  drawPage("network_setup_ready");
  memset(&credentials,0,sizeof(credentials));
  Serial.println("[CLOCK_UI_READY] boot=automatic date_mode=NTP SD=read_only; UI runs while waiting/offline");
  heapSample("after_network_start");
}
void applyDate(daily::Date date,bool diagnostic) {
  if(gesture.held() || weatherService.busy()) return;
  desk::Gate storageGate;if(!storageGate.held)return; // Defer SD/TLS peaks and held touch.
  const uint32_t started=millis();touchStarted=false;lcd.unloadFont();activeFont=0;sharedSpi.end();
  DailyContent candidate;candidate.date=date;candidate.state=ContentState::Error;dateLabels(candidate);
  bool okay=mountStorage() && prepareVerseLines(candidate);
  if(!running) return; // Daily font read/CRC failure stopped and freed cache.
  if(!okay) unavailableContent(candidate); // New date never displays an old verse/reference.
  homeMarquee.load(candidate); // Same SD ownership; new compact glyphs are optional UI data.
  reflectionQuestion.load(candidate);
  const bool glyphsOkay=validateCoverage(candidate);
  if(!startTouchBus()) {stopUi("TOUCH_RESTART");return;}
  if(!glyphsOkay) {stopUi("GLYPH_COVERAGE");return;}
  current=candidate;dayTransition.applied(date);dateError=current.state==ContentState::Error;
  if(diagnostic) {pages.select(0);pages.touched(millis());}
  lastClockLabel=dateModeLabel();
  if(pages.page()==0||pages.page()==1) drawPage("date_changed");else drawStatus();
  Serial.printf("DATE_APPLIED date=%04u-%02u-%02u verse=%u available=%s state=%u elapsed_ms=%u source=%s persistence=RAM_ONLY\n",date.year,date.month,date.day,current.ref.verse,current.state==ContentState::Available?"true":"false",unsigned(current.state),unsigned(millis()-started),testDateMode?"TEST":"NTP");
}
void updateDate() {
  if(!running) return;
  daily::Date desired;bool known=false;
  if(testDateMode) {desired=testDate;known=true;}else known=networkClock.date(desired);
  if(known && dayTransition.needs(desired) && !gesture.held()) applyDate(desired,false);
  if(!running) return;
  const char *label=dateModeLabel();
  if(strcmp(label,lastClockLabel)!=0) {lastClockLabel=label;if(pages.page()==0) drawPage("clock_state_changed");else drawStatus();}
}
void pollTouch() {
  if(!running || !touchStarted) return;
  const uint32_t now=millis(),gap=now-lastPoll;
  if(gap<board_config::TOUCH_POLL_MS) return;
  lastPoll=now;if(gap>maxPollGap) maxPollGap=gap;
  bool down=touch.touched();int x=0;float mappedY=0;
  if(down) {
    const TS_Point point=touch.getPoint();
    // R1 coefficients from this board's independent 5/5 test, maximum 2.8px.
    // evidence/hardware/display_touch_v02_touch_r1_result.json (2026-10-08).
    const float mappedX=board_config::TOUCH_X[0]*point.x+board_config::TOUCH_X[1]*point.y+board_config::TOUCH_X[2];
    mappedY=board_config::TOUCH_Y[0]*point.x+board_config::TOUCH_Y[1]*point.y+board_config::TOUCH_Y[2];
    down=mappedX>=-15 && mappedX<=335 && mappedY>=-15 && mappedY<=255;
    x=int(mappedX);if(x<0) x=0;if(x>319) x=319;
    if(down) pages.touched(now); // Suspend auto even during press debounce.
  }
  const auto event=gesture.update(now,down,x);
  if(event==TouchGesture::Event::Down) {
    touchPressX=x;touchPressY=int(mappedY);Serial.printf("TOUCH_DOWN x=%d y=%.1f page=%u\n",x,mappedY,pages.page()+1);drawStatus();
  } else if(event==TouchGesture::Event::Previous || event==TouchGesture::Event::Next) {
    pages.touched(now);
    deskTap();
  } else if(event==TouchGesture::Event::PinToggle) {
    pages.touched(now);deskLongPress();
  } else if(event==TouchGesture::Event::Release) {
    pages.touched(now);Serial.println("TOUCH_RELEASE after_long_hold no_tap=true");
  }
}
void setup() {
  Serial.begin(board_config::SERIAL_BAUD);delay(1000);
  desk::begin();weather_prefs::load();
  Serial.printf("WEATHER_SETTINGS boot_station=%s source=NVS_OR_DEFAULT\n",weather_prefs::STATIONS[weather_prefs::selected().load()].id);
  pinMode(board_config::SD_CS,OUTPUT);digitalWrite(board_config::SD_CS,HIGH);
  pinMode(board_config::TOUCH_CS,OUTPUT);digitalWrite(board_config::TOUCH_CS,HIGH);
  pinMode(board_config::BACKLIGHT,OUTPUT);digitalWrite(board_config::BACKLIGHT,HIGH);
  lcd.init();lcd.invertDisplay(false);lcd.setRotation(board_config::ROTATION);lcd.fillScreen(TFT_WHITE);
  // Attach PWM after driver initialization so its backlight pinMode cannot detach LEDC.
  pwmReady=ledcAttach(board_config::BACKLIGHT,5000,8);if(pwmReady)ledcWrite(board_config::BACKLIGHT,255);
  Serial.printf("BACKLIGHT pwm_ready=%s pin=%d runtime_unverified=true\n",pwmReady?"true":"false",board_config::BACKLIGHT);
  lcd.setTextColor(TFT_BLACK,TFT_WHITE);lcd.setTextFont(2);lcd.setCursor(16,24);lcd.println("Daily desk board");lcd.setCursor(16,52);lcd.println("Loading local SD data...");
  if(lcd.width()!=320 || lcd.height()!=240) {stopUi("DISPLAY_SIZE");return;}
  startUi();
  Serial.printf("READY %s running=%s page=%u\n",board_config::FIRMWARE_VERSION,running?"true":"false",pages.page()+1);
}
void handleCommand(const char *cmd) {
  if(strcmp(cmd,"?")==0) {
    Serial.printf("READY %s running=%s page=%u pinned=%s paused=%s poll_max_gap_ms=%u date=%04u-%02u-%02u verse=%u date_mode=%s available=%s auto=%s\n",board_config::FIRMWARE_VERSION,running?"true":"false",pages.page()+1,pages.pinned?"true":"false",pages.paused?"true":"false",unsigned(maxPollGap),current.date.year,current.date.month,current.date.day,current.ref.verse,testDateMode?"TEST":"NTP",current.state==ContentState::Available?"true":"false",pages.automatic?"true":"false");
    networkClock.report();
    Serial.printf("MARQUEE ready=%s paused=%s complete=%s x=%d budget=%u\n",homeMarquee.valid()?"true":"false",homeMarquee.motion.paused?"true":"false",homeMarquee.motion.complete?"true":"false",homeMarquee.motion.x(),unsigned(sizeof(HomeMarquee)+marquee::RAM_OVERHEAD));
    Serial.printf("REFLECTION ready=%s ram=%u error=%s\n",reflectionQuestion.valid()?"true":"false",unsigned(sizeof(ReflectionQuestion)),reflectionQuestion.error());
    Serial.printf("TIMER running=%s engaged=%s remaining_ms=%u settings_open=%s\n",timerRunning?"true":"false",timerEngaged?"true":"false",unsigned(remaining()),settingsShowing?"true":"false");
    Serial.printf("WEB_CONFIG ready=%s mode=%s ip=%s PIN=screen_only\n",webConfig.ready()?"true":"false",webConfig.isAP()?"AP":"STA",webConfig.ip().c_str());
    weatherService.report();weatherService.reportForecast();weatherService.extras.report();heapSample("query");desk::reportStorage();
  } else if(strcmp(cmd,"s")==0) {webConfig.enterSetup();if(running) drawPage("setup_diagnostic");}
  else if(strcmp(cmd,"u")==0) startUi();
  else if(running && strncmp(cmd,"d ",2)==0) {
    daily::Date date;
    if(!daily::parseDate(cmd+2,date)) {Serial.println("DATE_REJECTED invalid_date no_change=true");return;}
    if(gesture.held()) {Serial.println("DATE_REJECTED release_touch_first");return;}
    testDateMode=true;testDate=date;applyDate(date,true);
  } else if(strcmp(cmd,"r")==0) networkClock.retry();
  else if(strcmp(cmd,"o")==0) networkClock.offline();
  else if(running && strcmp(cmd,"c")==0) {testDateMode=false;dayTransition.attempted=false;updateDate();}
  else if(running && strcmp(cmd,"v")==0) {dayTransition.attempted=false;updateDate();}
  else if(running && strlen(cmd)==1 && cmd[0]>='1' && cmd[0]<='4') {pages.select(cmd[0]-'1');drawPage("serial");}
  else if(running && strcmp(cmd,"n")==0) {pages.next();drawPage("serial_next");}
  else if(running && strcmp(cmd,"p")==0) {pages.previous();drawPage("serial_previous");}
  else if(running && strcmp(cmd,"a")==0) {pages.automatic=!pages.automatic;pages.drawn(millis());Serial.printf("AUTO %s\n",pages.automatic?"true":"false");drawStatus();}
}
void loop() {
  // At most 32 serial bytes per iteration; no readString or blocking serial wait.
  for(unsigned i=0;i<32 && Serial.available();++i) {
    const char c=Serial.read();
    if(c=='\r'||c=='\n') {
      if(commandOverflow) Serial.println("COMMAND_REJECTED too_long");
      else if(commandLength) {serialCommand[commandLength]=0;handleCommand(serialCommand);}
      commandLength=0;commandOverflow=false;
    } else if(c<32 || c>126 || commandLength>=sizeof(serialCommand)-1) commandOverflow=true;
    else if(!commandOverflow) serialCommand[commandLength++]=c;
  }
  pollTouch();
  // Recovery AP owns the radio until settings are saved and the board reboots.
  if(!webConfig.isAP()) networkClock.tick();
  webConfig.tick(networkClock.connected(),networkClock.manualOffline);
  if(millis()-lastWebCheck>=500) {
    lastWebCheck=millis();String footer=webConfig.ip()+String(webConfig.isAP()?"AP":"STA");
    if(footer!=lastWebFooter) {lastWebFooter=footer;if(running) drawPage("network_mode_changed");}
  }
  if(millis()-lastDateCheck>=1000) {lastDateCheck=millis();updateDate();}
  weatherService.tick(networkClock.connected(),networkClock.valid,webConfig.isAP(),running && touchStarted && current.state!=ContentState::Waiting);
  if(running && !webConfig.isAP()) {auto weather=weatherService.snapshot();uint32_t minute=millis()/60000;
    if(weather.sequence!=lastWeatherSequence || minute!=lastWeatherMinute){lastWeatherSequence=weather.sequence;lastWeatherMinute=minute;if(pages.page()==0&&!forecastShowing)drawPage("weather_changed");}}
  static uint32_t lastForecastSequence=0,lastForecastMinute=0;auto forecast=weatherService.forecastSnapshot();uint32_t forecastMinute=millis()/60000;
  if(forecast.sequence!=lastForecastSequence||forecastMinute!=lastForecastMinute){lastForecastSequence=forecast.sequence;lastForecastMinute=forecastMinute;if(running&&!webConfig.isAP()&&forecastShowing)drawPage("forecast_changed");}
  static uint32_t lastExtrasSequence=0;auto extras=weatherService.extras.snapshot();if(extras.sequence!=lastExtrasSequence){lastExtrasSequence=extras.sequence;if(running&&!webConfig.isAP()&&pages.page()==2)drawPage("extras_changed");}
  if(running)deskTick();
  if(running && pages.resume(millis())) {Serial.printf("PAUSE_EXPIRED pause_ms=40000 auto=%s pinned=%s\n",pages.automatic?"true":"false",pages.pinned?"true":"false");drawStatus();}
  if(running && !menuShowing && !settingsShowing && !forecastShowing && !gesture.held() && pages.due(millis()) && !(pages.page()==0&&homeMarquee.blocksAuto())) {pages.nextAutomatic();drawPage("auto");}
  yield();
}
