#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <esp_http_server.h>
#include <esp_random.h>
#include <atomic>
#include "web_credentials.h"
#include "weather_preferences.h"
#include "desk_settings.h"
#include <cJSON.h>

#include "web_config_page.h"

class WebConfig {
 public:
  static bool load(wifi_config::Credentials &out) {
    Preferences prefs;if(!prefs.begin("cydweb",true)) return false;
    web_credentials::Record r;
    bool ok=prefs.getBytesLength("wifi_v1")==sizeof(r) && prefs.getBytes("wifi_v1",&r,sizeof(r))==sizeof(r);
    prefs.end();ok=ok && web_credentials::validRecord(r);
    if(ok) out=r.credentials;memset(&r,0,sizeof(r));return ok;
  }
  bool begin(bool configured,const wifi_config::Credentials &current) {
    active=current;hasCredentials=configured;snprintf(pinCode,sizeof(pinCode),"%06u",unsigned(esp_random()%1000000));
    const uint64_t mac=ESP.getEfuseMac();snprintf(apName,sizeof(apName),"CYD-Setup-%04X",unsigned((mac>>32)&0xffff));
    WiFi.persistent(false);
    if(!configured) startAP();
    httpd_config_t config=HTTPD_DEFAULT_CONFIG();
    config.stack_size=6144;config.task_priority=2;config.max_open_sockets=3;config.lru_purge_enable=true;
    config.max_uri_handlers=9;config.recv_wait_timeout=1;config.send_wait_timeout=1;config.uri_match_fn=httpd_uri_match_wildcard;
    if(httpd_start(&server,&config)!=ESP_OK) {Serial.println("WEB_CONFIG server_start=FAIL");return false;}
    if(!route("/",HTTP_GET,rootHandler) || !route("/save",HTTP_POST,saveHandler) || !route("/scan",HTTP_GET,scanHandler) || !route("/weather-settings",HTTP_GET,weatherSettingsHandler) || !route("/weather-save",HTTP_POST,weatherSaveHandler) || !route("/desk-settings",HTTP_GET,deskSettingsHandler) || !route("/desk-save",HTTP_POST,deskSaveHandler) || !route("/desk-command",HTTP_POST,deskCommandHandler) || !route("/*",HTTP_GET,notFoundHandler)) {
      httpd_stop(server);server=nullptr;Serial.println("WEB_CONFIG routes=FAIL");return false;
    }
    Serial.println("WEB_CONFIG ready local_HTTP=true secret_logs=false NVS_namespace=cydweb");return true;
  }
  void tick(bool connected,bool manualOffline) {
    if(!server) return;
    uint32_t now=millis();
    if(manualOffline) {if(apMode.load()) stopAP();downSince=0;return;}
    if(connected) {downSince=0;if(apMode.load()) stopAP();}
    else {
      if(!downSince) downSince=now;
      if(!apMode.load() && (!hasCredentials || uint32_t(now-downSince)>=120000)) startAP();
    }
    if(apMode.load()) dns.processNextRequest();
    if(restartPending.load()) {
      if(!restartSince) restartSince=now;
      if(uint32_t(now-restartSince)>=2000) {Serial.println("WEB_CONFIG restart saved=true");ESP.restart();}
    }
  }
  // Diagnostic entry: preserve NVS; a reboot resumes the saved home network.
  void enterSetup() {if(server && !apMode.load()) startAP();}
  bool isAP() const {return apMode.load();}
  bool ready() const {return server!=nullptr;}
  String ip() const {return isAP()?WiFi.softAPIP().toString():(WiFi.status()==WL_CONNECTED?WiFi.localIP().toString():String());}
  const char *pin() const {return pinCode;}
  const char *ssid() const {return apName;}
 private:
  httpd_handle_t server=nullptr;DNSServer dns;
  std::atomic<bool> apMode{false},restartPending{false};
  wifi_config::Credentials active;
  bool hasCredentials=false;
  uint32_t downSince=0,restartSince=0,authWindow=0,lastScan=0;unsigned badPins=0;
  char pinCode[7]={},apName[20]={};
  static WebConfig &self(httpd_req_t *req) {return *static_cast<WebConfig*>(req->user_ctx);}
  bool route(const char *uri,httpd_method_t method,esp_err_t (*fn)(httpd_req_t*)) {
    httpd_uri_t entry={};entry.uri=uri;entry.method=method;entry.handler=fn;entry.user_ctx=this;
    return httpd_register_uri_handler(server,&entry)==ESP_OK;
  }
  void startAP() {
    // Stop the failed home-network association before serving recovery clients.
    WiFi.disconnect(false,false);
    WiFi.mode(WIFI_AP_STA);
    char apPassword[12];snprintf(apPassword,sizeof(apPassword),"CYD-%s",pinCode);
    bool started=WiFi.softAP(apName,apPassword);memset(apPassword,0,sizeof(apPassword));
    if(!started) {Serial.println("WEB_CONFIG AP_start=FAIL");return;}
    dns.start(53,"*",WiFi.softAPIP());apMode.store(true);
    Serial.printf("WEB_CONFIG setup_AP=%s ip=%s PIN=screen_only\n",apName,WiFi.softAPIP().toString().c_str());
  }
  void stopAP() {dns.stop();WiFi.softAPdisconnect(true);WiFi.mode(WIFI_STA);apMode.store(false);Serial.println("WEB_CONFIG setup_AP=stopped");}
  static esp_err_t message(httpd_req_t *req,const char *status,const char *text) {
    httpd_resp_set_status(req,status);httpd_resp_set_type(req,"text/plain; charset=utf-8");httpd_resp_set_hdr(req,"Cache-Control","no-store");
    return httpd_resp_send(req,text,HTTPD_RESP_USE_STRLEN);
  }
  bool originOkay(httpd_req_t *req) {
    char value[96];size_t n=httpd_req_get_hdr_value_len(req,"Origin");
    if(!n) return true;
    if(n>=sizeof(value) || httpd_req_get_hdr_value_str(req,"Origin",value,sizeof(value))!=ESP_OK) return false;
    String lan="http://"+WiFi.localIP().toString(),ap="http://"+WiFi.softAPIP().toString();
    return lan==value || ap==value || lan+":80"==value || ap+":80"==value;
  }
  bool authorized(const char *pin) {
    uint32_t now=millis();if(uint32_t(now-authWindow)>=60000) {authWindow=now;badPins=0;}
    if(badPins>=5) return false;
    if(strcmp(pin,pinCode)!=0) {++badPins;return false;}return true;
  }
  static esp_err_t rootHandler(httpd_req_t *req) {
    httpd_resp_set_type(req,"text/html; charset=utf-8");httpd_resp_set_hdr(req,"Cache-Control","no-store");
    httpd_resp_set_hdr(req,"X-Content-Type-Options","nosniff");
    httpd_resp_set_hdr(req,"Content-Security-Policy","default-src 'self'; connect-src 'self' https://data.etabus.gov.hk; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'");
    httpd_resp_set_hdr(req,"Content-Encoding","gzip");
    return httpd_resp_send(req,reinterpret_cast<const char*>(WEB_CONFIG_PAGE_GZIP),sizeof(WEB_CONFIG_PAGE_GZIP));
  }
  static esp_err_t saveHandler(httpd_req_t *req) {
    auto &w=self(req);
    if(!w.originOkay(req)) return message(req,"403 Forbidden","來源不符，請直接開啟資訊牌的設定網址。");
    if(w.restartPending.load()) return message(req,"409 Conflict","已儲存，資訊牌正在重開機。");
    if(req->content_len<=0 || req->content_len>512) return message(req,"413 Content Too Large","設定資料太長。");
    char type[64];if(httpd_req_get_hdr_value_str(req,"Content-Type",type,sizeof(type))!=ESP_OK || strncmp(type,"application/x-www-form-urlencoded",33)!=0)
      return message(req,"415 Unsupported Media Type","請使用設定頁的表格儲存。");
    char body[513]={};size_t received=0;const uint32_t started=millis();
    while(received<size_t(req->content_len)) {
      int n=httpd_req_recv(req,body+received,req->content_len-received);
      if(n<=0 || uint32_t(millis()-started)>1500) {memset(body,0,sizeof(body));return message(req,"408 Request Timeout","傳送逾時，設定未更改。");}
      received+=n;
    }
    web_credentials::Form f;bool parsed=web_credentials::parse(body,received,f);memset(body,0,sizeof(body));
    if(!parsed) {memset(&f,0,sizeof(f));return message(req,"400 Bad Request","設定格式不正確，請檢查名稱及密碼長度。");}
    if(!w.authorized(f.pin)) {memset(&f,0,sizeof(f));return message(req,"403 Forbidden","PIN 不正確，或嘗試太多次；請核對畫面，稍後再試。");}
    wifi_config::Credentials c;bool valid=web_credentials::resolve(f,w.active,c);memset(&f,0,sizeof(f));
    if(!valid) {memset(&c,0,sizeof(c));return message(req,"400 Bad Request","Wi-Fi 名稱或密碼不正確。名稱最多 32 bytes；密碼需 8–63 bytes 或 64 位 hex。");}
    web_credentials::Record record;memset(&record,0,sizeof(record));record.version=1;record.credentials=c;record.checksum=web_credentials::checksum(c);Preferences prefs;
    bool saved=prefs.begin("cydweb",false) && prefs.putBytes("wifi_v1",&record,sizeof(record))==sizeof(record);prefs.end();
    wifi_config::Credentials check;saved=saved && load(check) && memcmp(&c,&check,sizeof(c))==0;
    memset(&record,0,sizeof(record));memset(&check,0,sizeof(check));memset(&c,0,sizeof(c));
    if(!saved) return message(req,"500 Internal Server Error","儲存或讀回確認失敗；請重新開啟設定頁再試。");
    w.restartPending.store(true);Serial.println("WEB_CONFIG saved_verified=true credentials=redacted");
    return message(req,"200 OK","設定已儲存。資訊牌約兩秒後重開機；連線成功後，請用畫面上的新網址和新 PIN 再開設定頁。");
  }
  static esp_err_t weatherSettingsHandler(httpd_req_t *req) {
    cJSON *root=cJSON_CreateObject(),*list=cJSON_CreateArray();
    if(!root || !list){cJSON_Delete(root);cJSON_Delete(list);return message(req,"503 Service Unavailable","記憶體不足，請稍後再試。");}
    cJSON_AddStringToObject(root,"selected",weather_prefs::STATIONS[weather_prefs::selected().load()].id);
    cJSON_AddItemToObject(root,"stations",list);
    for(const auto &station:weather_prefs::STATIONS){cJSON *item=cJSON_CreateObject();if(!item){cJSON_Delete(root);return message(req,"503 Service Unavailable","記憶體不足。");}cJSON_AddStringToObject(item,"id",station.id);cJSON_AddStringToObject(item,"name",station.name);cJSON_AddItemToArray(list,item);}
    char *json=cJSON_PrintUnformatted(root);cJSON_Delete(root);
    if(!json)return message(req,"503 Service Unavailable","記憶體不足。");
    httpd_resp_set_type(req,"application/json; charset=utf-8");httpd_resp_set_hdr(req,"Cache-Control","no-store");
    esp_err_t result=httpd_resp_send(req,json,HTTPD_RESP_USE_STRLEN);cJSON_free(json);return result;
  }
  static esp_err_t weatherSaveHandler(httpd_req_t *req) {
    auto &w=self(req);if(!w.originOkay(req))return message(req,"403 Forbidden","來源不符。");
    if(w.restartPending.load())return message(req,"409 Conflict","資訊牌正在重開機，請稍後再試。");
    char type[64]={};if(httpd_req_get_hdr_value_str(req,"Content-Type",type,sizeof(type))!=ESP_OK || strcmp(type,"application/json")!=0)return message(req,"415 Unsupported Media Type","格式不符。");
    if(req->content_len<1 || req->content_len>128)return message(req,"413 Content Too Large","資料太長。");
    char body[129]={};size_t received=0;uint32_t start=millis();
    while(received<size_t(req->content_len)){int n=httpd_req_recv(req,body+received,req->content_len-received);if(n<=0 || uint32_t(millis()-start)>1500){memset(body,0,sizeof(body));return message(req,"408 Request Timeout","傳送逾時，設定未更改。");}received+=n;}
    cJSON *root=strlen(body)==received?cJSON_ParseWithLengthOpts(body,received+1,nullptr,true):nullptr;memset(body,0,sizeof(body));
    if(!cJSON_IsObject(root) || cJSON_GetArraySize(root)!=2){cJSON_Delete(root);return message(req,"400 Bad Request","設定格式不符。");}
    cJSON *pin=cJSON_GetObjectItemCaseSensitive(root,"pin"),*station=cJSON_GetObjectItemCaseSensitive(root,"station");
    if(!cJSON_IsString(pin) || strlen(pin->valuestring)!=6 || !cJSON_IsString(station) || strlen(station->valuestring)>=24){cJSON_Delete(root);return message(req,"400 Bad Request","設定格式不符。");}
    bool auth=w.authorized(pin->valuestring);int id=weather_prefs::find(station->valuestring);cJSON_Delete(root);
    if(!auth)return message(req,"403 Forbidden","PIN 不正確，或嘗試太多次。");
    if(id<0)return message(req,"400 Bad Request","未知測站。");
    if(!weather_prefs::save(id))return message(req,"500 Internal Server Error","儲存或讀回失敗。");
    Serial.printf("WEATHER_SETTINGS saved_verified=true station=%s\n",weather_prefs::STATIONS[id].id);
    return message(req,"200 OK","已儲存天氣地區。連上 Wi-Fi 後會取得所選測站資料；Wi-Fi 設定不受影響。");
  }
  static bool receiveJson(httpd_req_t *req,cJSON *&root,size_t limit){root=nullptr;char type[64]={};if(httpd_req_get_hdr_value_str(req,"Content-Type",type,sizeof(type))!=ESP_OK||strcmp(type,"application/json")!=0||req->content_len<1||size_t(req->content_len)>limit)return false;char *body=static_cast<char*>(malloc(req->content_len+1));if(!body)return false;size_t n=0;uint32_t start=millis();while(n<size_t(req->content_len)){int got=httpd_req_recv(req,body+n,req->content_len-n);if(got<=0||millis()-start>2000){free(body);return false;}n+=got;}body[n]=0;
    unsigned depth=0,objects=0,seps=0;bool quote=false,escape=false,shape=true;for(size_t i=0;i<n;++i){char c=body[i];if(quote){if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='"')quote=false;continue;}if(c=='"')quote=true;else if(c=='{'||c=='['){if(++depth>6||++objects>20){shape=false;break;}}else if(c=='}'||c==']'){if(!depth){shape=false;break;}--depth;}else if(c==','&&++seps>80){shape=false;break;}}
    if(shape&&!depth&&!quote&&strlen(body)==n)root=cJSON_ParseWithLengthOpts(body,n+1,nullptr,true);memset(body,0,n);free(body);return cJSON_IsObject(root);
  }
  static esp_err_t deskSettingsHandler(httpd_req_t *req){auto &w=self(req);char pin[7]={};if(!w.originOkay(req)||httpd_req_get_hdr_value_str(req,"X-Setup-Pin",pin,sizeof(pin))!=ESP_OK||!w.authorized(pin))return message(req,"403 Forbidden","請先輸入正確的六位 PIN。");desk::Gate gate;if(!gate.held)return message(req,"503 Service Unavailable","正在更新網絡資料，請數秒後再試。");auto v=new(std::nothrow) desk::Config;if(!v)return message(req,"503 Service Unavailable","記憶體不足。");bool ok=desk::copy(*v);auto root=ok?desk::json(*v):nullptr;delete v;char *json=root?cJSON_PrintUnformatted(root):nullptr;cJSON_Delete(root);if(!json)return message(req,"503 Service Unavailable","設定讀取失敗。");httpd_resp_set_type(req,"application/json; charset=utf-8");httpd_resp_set_hdr(req,"Cache-Control","no-store");auto result=httpd_resp_send(req,json,HTTPD_RESP_USE_STRLEN);cJSON_free(json);return result;}
  static esp_err_t deskSaveHandler(httpd_req_t *req){auto &w=self(req);if(!w.originOkay(req)||w.restartPending.load())return message(req,"409 Conflict","來源不符或正在重開機。");desk::Gate gate;if(!gate.held||ESP.getFreeHeap()<60000)return message(req,"503 Service Unavailable","正在更新網絡資料，請數秒後再儲存。");cJSON *root=nullptr;if(!receiveJson(req,root,12288)){cJSON_Delete(root);return message(req,"400 Bad Request","設定格式或長度不符。");}auto pin=desk::get(root,"pin");if(!cJSON_IsString(pin)||strlen(pin->valuestring)!=6||!w.authorized(pin->valuestring)){cJSON_Delete(root);return message(req,"403 Forbidden","PIN 不正確或嘗試太多次。");}auto v=new(std::nothrow) desk::Config;bool ok=v&&desk::copy(*v)&&desk::parse(root,*v);cJSON_Delete(root);if(!ok){delete v;return message(req,"400 Bad Request","請檢查QR 網址、分鐘數、亮度及所選巴士站。");}if(!desk::styledLabels(*v)){delete v;return message(req,"409 Conflict","此設定頁的字體版本較舊，請重新整理頁面，確認顯示目前版本後再讀取及儲存。原有收藏不受影響。");}desk::SaveFailure failure;ok=desk::save(*v,&failure);delete v;if(!ok){const char *hint=failure.code==ESP_ERR_NVS_NOT_ENOUGH_SPACE?"設定儲存空間不足":failure.code==ESP_ERR_NO_MEM?"儲存時記憶體不足":strcmp(failure.stage,"encode")==0?"設定字圖超出精簡儲存上限":strcmp(failure.stage,"apply")==0?"已寫入及核對，但畫面設定未套用":"設定寫入或核對失敗";char text[256];snprintf(text,sizeof(text),"%s（%s / %s）。請讀取目前設定核對。",hint,failure.stage,esp_err_to_name(failure.code));return message(req,"500 Internal Server Error",text);}Serial.println("DESK_SETTINGS saved_verified=true content=redacted");return message(req,"200 OK","已儲存及讀回核對。畫面設定即時生效；巴士會再核對官方路線站點及取得 ETA。不用重開機。");}
  static esp_err_t deskCommandHandler(httpd_req_t *req){auto &w=self(req);if(!w.originOkay(req))return message(req,"403 Forbidden","來源不符。");cJSON *root=nullptr;if(!receiveJson(req,root,128)){cJSON_Delete(root);return message(req,"400 Bad Request","格式不符。");}auto pin=desk::get(root,"pin"),a=desk::get(root,"action");bool auth=cJSON_IsString(pin)&&strlen(pin->valuestring)==6&&w.authorized(pin->valuestring);const char *actions[]={"count","toggle","reset","menu"};const unsigned codes[]={2,4,5,7};unsigned cmd=0;if(cJSON_IsString(a))for(unsigned i=0;i<4;++i)if(strcmp(a->valuestring,actions[i])==0)cmd=codes[i];cJSON_Delete(root);if(!auth)return message(req,"403 Forbidden","PIN 不正確。");if(!cmd)return message(req,"400 Bad Request","未知操作。");unsigned expected=0;if(!desk::command().compare_exchange_strong(expected,cmd))return message(req,"409 Conflict","上一個操作仍在處理，請稍後再試。");return message(req,"202 Accepted","操作已排隊，請查看 CYD 畫面。");}
  static esp_err_t scanHandler(httpd_req_t *req) {
    auto &w=self(req);char pin[7]={};
    if(!w.originOkay(req) || httpd_req_get_hdr_value_str(req,"X-Setup-Pin",pin,sizeof(pin))!=ESP_OK || !w.authorized(pin))
      return message(req,"403 Forbidden","請輸入正確的畫面 PIN。");
    int n=WiFi.scanComplete();
    if(n==WIFI_SCAN_RUNNING) return message(req,"202 Accepted","scanning");
    if(n==WIFI_SCAN_FAILED) {
      if(w.lastScan && uint32_t(millis()-w.lastScan)<15000) return message(req,"429 Too Many Requests","請等候 15 秒再掃描。");
      w.lastScan=millis();WiFi.scanNetworks(true);
      return message(req,"202 Accepted","scanning");
    }
    String json;json.reserve(3072);json+='[';
    for(int i=0,shown=0;i<n && shown<12;++i) {
      String name=WiFi.SSID(i);if(!name.length() || name.length()>32) continue;
      if(shown++) json+=',';json+='"';
      for(size_t k=0;k<name.length();++k) {
        unsigned char c=name[k];if(c=='"' || c=='\\') {json+='\\';json+=char(c);}
        else if(c<32 || c==127) {char escaped[7];snprintf(escaped,sizeof(escaped),"\\u%04x",c);json+=escaped;}
        else json+=char(c);
      }
      json+='"';
    }
    json+=']';WiFi.scanDelete();httpd_resp_set_type(req,"application/json");httpd_resp_set_hdr(req,"Cache-Control","no-store");
    return httpd_resp_send(req,json.c_str(),json.length());
  }
  static esp_err_t notFoundHandler(httpd_req_t *req) {
    auto &w=self(req);if(!w.isAP()) return message(req,"404 Not Found","Not found");
    String url="http://"+WiFi.softAPIP().toString()+"/";
    httpd_resp_set_status(req,"302 Found");httpd_resp_set_hdr(req,"Location",url.c_str());return httpd_resp_send(req,"",0);
  }
};
