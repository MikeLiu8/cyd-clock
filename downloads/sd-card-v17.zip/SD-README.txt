CYD 時鐘 Stage13-v17 SD 資料包
將此ZIP解壓後的 bible、fonts、reflections 資料夾及 daily_verses.csv 直接複製到SD卡最外層。
正確：/daily_verses.csv、/bible/JHN/003.txt、/fonts/marquee/10-14.mqf、/reflections/10-14.txt。
不要多包一層 sd-card 資料夾。資料包不含wifi.cfg、密碼或板上設定。
使用FAT32 SD卡；複製前先關掉CYD電源，完成後安全退出再插回。
經文來源：BibleGateway繁體和合本 CUV，來源頁標示在美國為public domain；沒有宣稱所有司法地區權利狀態相同。
https://classic.biblegateway.com/versions/Chinese-Union-Version-Traditional-CUV/
字形由Noto Sans TC生成，各字形目錄附SIL OFL授權。
反思為本專案全年個人默想問題，與經文分開，並非經文原文。
