#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
namespace marquee {
constexpr unsigned MAX_GLYPHS=64, MAX_CHARS=128, RECORD=40, HEADER=24;
constexpr unsigned FILE_LIMIT=HEADER+MAX_GLYPHS*RECORD, WIDTH=304, HEIGHT=24;
// Frame allocation includes sentinel byte; TFT pushImage uses a 16-bit line on stack.
constexpr unsigned RAM_OVERHEAD=WIDTH*HEIGHT/8+1+WIDTH*2+128+64;
inline uint16_t u16(const uint8_t *p){return p[0]|uint16_t(p[1])<<8;}
inline uint32_t u32(const uint8_t *p){return u16(p)|uint32_t(u16(p+2))<<16;}
inline uint32_t crcStep(uint32_t c,const uint8_t *p,size_t n){while(n--){c^=*p++;for(int i=0;i<8;++i)c=(c>>1)^((c&1)?0xedb88320u:0);}return c;}
inline uint32_t crc(const uint8_t *p,size_t n){return ~crcStep(~0u,p,n);}
inline bool codepoint(const char *s,size_t &i,uint16_t &cp){
 unsigned a=uint8_t(s[i++]);if(!a)return false;if(a<128){cp=a;return true;}
 unsigned n=a>=0xe0&&a<=0xef?2:a>=0xc2&&a<=0xdf?1:0;if(!n)return false;
 unsigned v=a&((1u<<(6-n))-1),minimum=n==2?0x800:0x80;
 while(n--){unsigned b=uint8_t(s[i]);if(b<128||b>=192)return false;++i;v=(v<<6)|(b&63);}
 if(v<minimum||v>65535||(v>=0xd800&&v<=0xdfff))return false;cp=v;return true;
}
struct Asset {
 const uint8_t *bytes=nullptr;unsigned count=0;
 bool validate(const uint8_t *p,size_t n,unsigned month,unsigned day,const char *book,unsigned chapter,unsigned verse,uint32_t textCrc){
  bytes=nullptr;count=0;if(n<HEADER||n>FILE_LIMIT||memcmp(p,"MQF1",4)||p[4]!=month||p[5]!=day||memcmp(p+6,book,3)||p[9]||u16(p+10)!=chapter||u16(p+12)!=verse||u32(p+16)!=textCrc)return false;
  unsigned c=u16(p+14);if(!c||c>MAX_GLYPHS||n!=HEADER+c*RECORD||crc(p+HEADER,n-HEADER)!=u32(p+20))return false;
  unsigned prev=0;for(unsigned i=0;i<c;++i){auto r=p+HEADER+i*RECORD;unsigned cp=u16(r);if(cp<=prev||cp<33||(cp>=0xd800&&cp<=0xdfff)||!r[2]||r[2]>16||r[3])return false;bool ink=false;for(unsigned j=4;j<RECORD;++j)ink|=r[j]!=0;if(!ink)return false;prev=cp;}
  bytes=p;count=c;return true;
 }
 int index(uint16_t cp)const{for(unsigned i=0;i<count;++i)if(u16(bytes+HEADER+i*RECORD)==cp)return i;return -1;}
 const uint8_t *record(unsigned i)const{return bytes+HEADER+i*RECORD;}
};
struct Text {
 uint8_t indices[MAX_CHARS]={};unsigned count=0,width=0;
 bool append(const char *s,const Asset &a){size_t i=0;while(s[i]){uint16_t cp;if(count==MAX_CHARS||!codepoint(s,i,cp))return false;int k=cp==32?254:cp==0x3000?255:a.index(cp);if(k<0)return false;indices[count++]=k;width+=k==254?8:k==255?16:a.record(k)[2];}return true;}
 unsigned advance(unsigned i,const Asset &a)const{return indices[i]==254?8:indices[i]==255?16:a.record(indices[i])[2];}
};
// elapsed time advances only while the Home strip is visible and unpaused.
struct Motion {
 uint32_t elapsed=0,last=0;unsigned textWidth=0;bool visible=false,paused=false,complete=false;
 void restart(uint32_t now,unsigned width){elapsed=0;last=now;textWidth=width;visible=false;paused=false;complete=false;}
 uint32_t duration()const{return ((WIDTH+textWidth)*1000u+23)/24;}
 void tick(uint32_t now,bool shown,bool repeat){
  uint32_t delta=now-last;last=now;if(shown&&visible&&!paused){elapsed+=delta;if(elapsed>=duration()){complete=true;if(repeat&&elapsed>=duration()+1000)elapsed%=duration()+1000;}}visible=shown;
 }
 int x()const{return elapsed>=duration()?-int(textWidth):int(WIDTH)-int(elapsed*24u/1000);}
 bool blocksAuto(bool ready)const{return ready&&(paused||!complete);}
};
}
