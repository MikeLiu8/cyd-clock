#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
namespace daily {
struct Date {unsigned year=0,month=0,day=0;};
struct Reference {char book[4]={};unsigned chapter=0,verse=0;};
enum class Status {Found,NotFound,Invalid,Duplicate,TooLarge,Timeout};
inline bool leap(unsigned y) {return y%4==0 && (y%100!=0 || y%400==0);}
inline bool valid(Date d) {
  constexpr unsigned days[]={31,28,31,30,31,30,31,31,30,31,30,31};
  return d.year>=1 && d.year<=9999 && d.month>=1 && d.month<=12 && d.day>=1 && d.day<=days[d.month-1]+(d.month==2 && leap(d.year));
}
inline bool number(const char *s,unsigned &out,unsigned max) {
  if(!*s) return false;unsigned n=0;
  while(*s) {if(*s<'0'||*s>'9') return false;n=n*10+unsigned(*s++-'0');if(n>max) return false;}
  out=n;return true;
}
inline bool parseDate(const char *s,Date &out) {
  if(strlen(s)!=10 || s[4]!='-' || s[7]!='-') return false;
  char y[5]={},m[3]={},d[3]={};memcpy(y,s,4);memcpy(m,s+5,2);memcpy(d,s+8,2);
  Date candidate;
  if(!number(y,candidate.year,9999)||!number(m,candidate.month,12)||!number(d,candidate.day,31)||!valid(candidate)) return false;
  out=candidate;return true;
}
// Gregorian weekday, 0=Sunday; independent of any network clock/timezone.
inline unsigned weekday(Date d) {
  static constexpr unsigned offsets[]={0,3,2,5,0,3,5,1,4,6,2,4};
  unsigned y=d.year-(d.month<3);return (y+y/4-y/100+y/400+offsets[d.month-1]+d.day)%7;
}
inline bool parseRow(char *line,unsigned &month,unsigned &day,Reference &ref) {
  char *parts[4]={line};unsigned commas=0;
  for(char *p=line;*p;++p) if(*p==',') {if(commas>=3) return false;*p=0;parts[++commas]=p+1;}
  if(commas!=3||strlen(parts[0])!=5||parts[0][2]!='-'||strlen(parts[1])!=3) return false;
  char m[3]={parts[0][0],parts[0][1],0},d[3]={parts[0][3],parts[0][4],0};
  if(!number(m,month,12)||!number(d,day,31)||!valid({2000,month,day})) return false;
  for(unsigned i=0;i<3;++i) {char c=parts[1][i];if(!((c>='A'&&c<='Z')||(c>='1'&&c<='3'))) return false;ref.book[i]=c;}
  ref.book[3]=0;
  return number(parts[2],ref.chapter,999)&&ref.chapter>0&&number(parts[3],ref.verse,999)&&ref.verse>0;
}
// Fixed 64-byte line buffer, full bounded scan catches duplicate target dates.
// Reader returns -1 EOF, -2 I/O/timeout. No whole CSV in RAM.
template<class Reader> Status find(Reader &reader,Date date,Reference &out,size_t maxBytes=65536) {
  if(!valid(date)) return Status::Invalid;
  char line[64]={};size_t length=0,count=0;unsigned found=0;Reference candidate;
  auto process=[&]() {
    line[length]=0;if(length && line[length-1]=='\r') line[--length]=0;
    if(!length || line[0]=='#') return Status::Found;
    unsigned m=0,d=0;Reference ref;
    if(!parseRow(line,m,d,ref)) return Status::Invalid;
    if(m==date.month && d==date.day) {candidate=ref;if(++found>1) return Status::Duplicate;}
    return Status::Found;
  };
  // Permit UTF8 BOM only at start, including its bytes in the scan cap.
  int c=reader.read();
  if(c==0xef) {count=3;if(count>maxBytes) return Status::TooLarge;if(reader.read()!=0xbb||reader.read()!=0xbf) return Status::Invalid;c=reader.read();}
  while(c!=-1) {
    if(c<0) return Status::Timeout;
    if(++count>maxBytes) return Status::TooLarge;
    if(c=='\n') {Status s=process();if(s!=Status::Found) return s;length=0;}
    else {if(c==0 || c>127 || length>=sizeof(line)-1) return Status::Invalid;line[length++]=char(c);}
    c=reader.read();
  }
  if(length) {Status s=process();if(s!=Status::Found) return s;}
  if(!found) return Status::NotFound;out=candidate;return Status::Found;
}
}
