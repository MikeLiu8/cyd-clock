#pragma once
#include <stdint.h>
// Debounce before recognizing one tap OR one long hold per contact.
class TouchGesture {
 public:
  enum class Event {None, Down, Previous, Next, PinToggle, Release};
  static constexpr uint32_t PRESS_MS=60, RELEASE_MS=80, LONG_MS=1500;
  bool held() const { return stable; }
  Event update(uint32_t now,bool down,int x) {
    if(down!=candidate) {candidate=down;changedAt=now;if(down) candidateX=x;}
    if(candidate!=stable && uint32_t(now-changedAt)>=(candidate?PRESS_MS:RELEASE_MS)) {
      stable=candidate;
      if(stable) {pressedAt=now;pressX=candidateX;longSent=false;return Event::Down;}
      if(longSent) return Event::Release;
      return pressX<160 ? Event::Previous : Event::Next;
    }
    if(stable && candidate && !longSent && uint32_t(now-pressedAt)>=LONG_MS) {
      longSent=true;return Event::PinToggle;
    }
    return Event::None;
  }
 private:
  bool candidate=false,stable=false,longSent=false;
  uint32_t changedAt=0,pressedAt=0;
  int candidateX=0,pressX=0;
};
