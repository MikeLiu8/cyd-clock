#pragma once
#include <stdint.h>
#include <string.h>
// Project-local, fixed Version 5-L byte encoder, ASCII URL <=100 bytes.
// QR Model 2 layout/ECC facts cross-checked against Project Nayuki's ISO-based reference.
// No package installation, heap or external runtime dependency. Phone scan gate pending.
class UrlQr {
 public:
 static constexpr int SIZE=37;
 bool dark(int x,int y)const{return (modules[(y*SIZE+x)/8]>>(7-(y*SIZE+x)%8))&1;}
 bool encode(const char *url){size_t n=strlen(url);if(!n||n>100)return false;memset(modules,0,sizeof(modules));memset(reserved,0,sizeof(reserved));uint8_t code[134]={};unsigned at=0;
 auto put=[&](unsigned value,unsigned count){for(int k=int(count)-1;k>=0;--k){if((value>>k)&1)code[at/8]|=1<<(7-at%8);++at;}};
 put(4,4);put(n,8);for(size_t i=0;i<n;++i)put(static_cast<unsigned char>(url[i]),8);put(0,4);while(at%8)put(0,1);bool pad=false;while(at<108*8){put(pad?0x11:0xec,8);pad=!pad;}
 uint8_t polynomial[27]={1};unsigned degree=0;uint8_t root=1;
 for(unsigned i=0;i<26;++i){uint8_t next[27]={};for(unsigned j=0;j<=degree;++j){next[j]^=polynomial[j];next[j+1]^=multiply(polynomial[j],root);}memcpy(polynomial,next,sizeof(next));++degree;root=multiply(root,2);}
 uint8_t remainder[134];memcpy(remainder,code,134);for(unsigned i=0;i<108;++i){uint8_t f=remainder[i];for(unsigned j=0;j<27;++j)remainder[i+j]^=multiply(f,polynomial[j]);}memcpy(code+108,remainder+108,26);
 for(int i=0;i<SIZE;++i){fixed(6,i,i%2==0);fixed(i,6,i%2==0);}finder(3,3);finder(SIZE-4,3);finder(3,SIZE-4);
 for(int y=28;y<=32;++y)for(int x=28;x<=32;++x){int dx=x-30,dy=y-30;int d=(dx<0?-dx:dx)>(dy<0?-dy:dy)?(dx<0?-dx:dx):(dy<0?-dy:dy);fixed(x,y,d!=1);}
 format();unsigned bit=0;bool up=true;
 for(int right=SIZE-1;right>=1;right-=2){if(right==6)--right;for(int row=0;row<SIZE;++row){int y=up?SIZE-1-row:row;for(int column=0;column<2;++column){int x=right-column,index=y*SIZE+x;if(!marked(index)){bool value=bit<134*8?((code[bit/8]>>(7-bit%8))&1):false;++bit;set(index,value^((x+y)%2==0));}}}up=!up;}
 format();return bit==134*8+7;
 }
 private:
 uint8_t modules[(SIZE*SIZE+7)/8]={},reserved[(SIZE*SIZE+7)/8]={};
 static uint8_t multiply(uint8_t a,uint8_t b){unsigned v=0;for(unsigned i=0;i<8;++i){if(b&1)v^=a;bool carry=a&0x80;a<<=1;if(carry)a^=0x1d;b>>=1;}return uint8_t(v);}
 bool marked(int i)const{return (reserved[i/8]>>(7-i%8))&1;}
 void set(int i,bool b){if(b)modules[i/8]|=1<<(7-i%8);else modules[i/8]&=~(1<<(7-i%8));}
 void fixed(int x,int y,bool b){if(x<0||y<0||x>=SIZE||y>=SIZE)return;int i=y*SIZE+x;reserved[i/8]|=1<<(7-i%8);set(i,b);}
 void finder(int cx,int cy){for(int y=-4;y<=4;++y)for(int x=-4;x<=4;++x){int dx=x<0?-x:x,dy=y<0?-y:y,d=dx>dy?dx:dy;fixed(cx+x,cy+y,d<4&&d!=2);}}
 void format(){unsigned value=8,r=value;for(unsigned i=0;i<10;++i)r=(r<<1)^((r&0x200)?0x537:0);unsigned bits=((value<<10)|r)^0x5412;
 int x[15]={8,8,8,8,8,8,8,8,7,5,4,3,2,1,0};int y[15]={0,1,2,3,4,5,7,8,8,8,8,8,8,8,8};for(int i=0;i<15;++i){bool b=(bits>>i)&1;fixed(x[i],y[i],b);if(i<8)fixed(SIZE-1-i,8,b);else fixed(8,SIZE-15+i,b);}fixed(8,SIZE-8,true);
 }
};
