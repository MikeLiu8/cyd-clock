// Native label pixels shared by the real setup page and the desktop preview.
// Keep each existing648byte NVS field:8byte style header +128px bitmap +zeros.
function busLabelBits(text,size,weight){
 const width=128,height=size===18?24:18,c=document.createElement('canvas');c.width=width;c.height=height;
 const ctx=c.getContext('2d');ctx.fillStyle='white';ctx.fillRect(0,0,width,height);ctx.fillStyle='black';ctx.font=weight+' '+size+'px system-ui, sans-serif';ctx.textBaseline='alphabetic';
 const limit=size===18?94:110;
 let shown=text;while(shown&&ctx.measureText(shown).width>limit)shown=shown.slice(0,-1);
 if(shown!==text){while(shown&&ctx.measureText(shown+'…').width>limit)shown=shown.slice(0,-1);shown+='…';}
 const metrics=ctx.measureText(shown),ascent=metrics.actualBoundingBoxAscent||size,descent=metrics.actualBoundingBoxDescent||3;
 ctx.fillText(shown,0,Math.round(Math.max(ascent,(height-ascent-descent)/2+ascent)));
 const data=ctx.getImageData(0,0,width,height).data,out=new Uint8Array(648);out.set([67,89,68,13,width,height,size,weight/100]);
 for(let i=0;i<width*height;i++)if(data[i*4]+data[i*4+1]+data[i*4+2]<500)out[8+(i>>3)]|=1<<(7-(i&7));
 return out;
}
