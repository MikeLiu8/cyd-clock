#pragma once
#include "marquee_core.h"
class HomeMarquee {
 uint8_t buffer[marquee::FILE_LIMIT]={};marquee::Asset asset;marquee::Text text;
 TFT_eSprite strip;bool ready=false;int lastPage=-1;uint32_t frameAt=0;
 const char *problem="等候每日金句";
 public:
 marquee::Motion motion;
 explicit HomeMarquee(TFT_eSPI *display):strip(display){}
 bool valid()const{return ready;}
 const char *error()const{return problem;}
 void clear(uint32_t now,const char *reason){ready=false;problem=reason;text={};asset={};motion.restart(now,0);}
 // Called only while SD owns VSPI, inside the existing storage/network gate.
 void load(const DailyContent &d){
  clear(millis(),"今日金句未提供");if(d.state!=ContentState::Available)return;
  const BibleBook *book=knownBook(d.ref.book);if(!book){problem="金句資料錯誤";return;}
  char ref[80];snprintf(ref,sizeof(ref),"%s %u:%u",book->name,d.ref.chapter,d.ref.verse);
  uint32_t c=marquee::crcStep(~0u,reinterpret_cast<const uint8_t*>(d.verse),strlen(d.verse));
  c=marquee::crcStep(c,reinterpret_cast<const uint8_t*>("　"),3);c=marquee::crcStep(c,reinterpret_cast<const uint8_t*>(ref),strlen(ref));
  char path[48];snprintf(path,sizeof(path),"/fonts/marquee/%02u-%02u.mqf",d.date.month,d.date.day);
  File f=SD.open(path,FILE_READ);if(!f||f.isDirectory()){f.close();problem="金句字體未準備";return;}
  size_t n=f.size();bool read=n<=sizeof(buffer)&&f.read(buffer,n)==n;f.close();
  if(!read||!asset.validate(buffer,n,d.date.month,d.date.day,d.ref.book,d.ref.chapter,d.ref.verse,~c)){problem="金句字體損壞";return;}
  if(!text.append(d.verse,asset)||!text.append("　",asset)||!text.append(ref,asset)){problem="金句字形不完整";return;}
  if(!strip.created()){
   if(ESP.getFreeHeap()<70000||heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)<marquee::WIDTH*marquee::HEIGHT/8+512){problem="金句記憶體不足";return;}
   strip.setColorDepth(1);if(!strip.createSprite(marquee::WIDTH,marquee::HEIGHT)){problem="金句記憶體不足";return;}
  }
  ready=true;problem="";motion.restart(millis(),text.width);
  Serial.printf("MARQUEE_ASSET glyphs=%u chars=%u width=%u bytes=%u budget=%u valid=true\n",asset.count,text.count,text.width,unsigned(n),unsigned(sizeof(*this)+marquee::RAM_OVERHEAD));
 }
 void page(unsigned p){if(lastPage!=int(p)){lastPage=p;motion.restart(millis(),text.width);}}
 bool tick(bool visible){motion.tick(millis(),visible,true);if(!ready||!visible||millis()-frameAt<42)return false;frameAt=millis();return true;}
 void toggle(){if(ready){motion.paused=!motion.paused;motion.last=millis();}}
 bool blocksAuto()const{return motion.blocksAuto(ready);}
 void paint(uint16_t fg,uint16_t bg){
  if(!ready)return;strip.setBitmapColor(fg,bg);strip.fillSprite(0);int x=motion.x();
  for(unsigned i=0;i<text.count;++i){unsigned k=text.indices[i];if(k<asset.count&&x>-16&&x<int(marquee::WIDTH))strip.drawBitmap(x,3,asset.record(k)+4,16,18,1);x+=text.advance(i,asset);}
  strip.pushSprite(16,212);
 }
};
static_assert(sizeof(HomeMarquee)+marquee::RAM_OVERHEAD<=5120,"Marquee state, inherited Sprite and frame buffer must fit 5KB budget");
