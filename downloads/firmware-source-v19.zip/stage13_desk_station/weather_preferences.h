#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include <atomic>

namespace weather_prefs {
struct Station {const char *id,*name,*english;};
// Stable IDs are persisted, not list positions. Names match the HKO report.
constexpr Station STATIONS[]={
 {"tai_po","大埔","Tai Po station"},{"hko","香港天文台","HKO Headquarters"},
 {"sha_tin","沙田","Sha Tin"},{"kwun_tong","觀塘","Kwun Tong"},
 {"yuen_long","元朗公園","Yuen Long Park"},{"tuen_mun","屯門","Tuen Mun"},
 {"ta_kwu_ling","打鼓嶺","Ta Kwu Ling"},{"shek_kong","石崗","Shek Kong"},
 {"tseung_kwan_o","將軍澳","Tseung Kwan O"},{"sai_kung","西貢","Sai Kung"},
 {"tsing_yi","青衣","Tsing Yi"},{"tsuen_wan","荃灣城門谷","Tsuen Wan Shing Mun"},
 {"kowloon_city","九龍城","Kowloon City"},{"wong_tai_sin","黃大仙","Wong Tai Sin"},
 {"sham_shui_po","深水埗","Sham Shui Po"},{"kings_park","京士柏","King's Park"},
 {"happy_valley","跑馬地","Happy Valley"},{"shau_kei_wan","筲箕灣","Shau Kei Wan"},
 {"stanley","赤柱","Stanley"},{"wong_chuk_hang","黃竹坑","Wong Chuk Hang"},
 {"hk_park","香港公園","Hong Kong Park"},{"cheung_chau","長洲","Cheung Chau"},
 {"airport","赤鱲角","Hong Kong Airport"},{"lau_fau_shan","流浮山","Lau Fau Shan"},
 {"tai_mei_tuk","大美督","Tai Mei Tuk"},{"kai_tak","啟德跑道公園","Kai Tak Runway Park"},
 {"tsuen_wan_ho","荃灣可觀","Tsuen Wan Ho Koon"}
};
constexpr int COUNT=sizeof(STATIONS)/sizeof(STATIONS[0]);
inline int find(const char *id) {for(int i=0;i<COUNT;++i) if(strcmp(id,STATIONS[i].id)==0)return i;return -1;}
inline std::atomic<int> &selected() {static std::atomic<int> value{0};return value;}
inline int load() {
 Preferences p;char id[24]={};int value=0;
 if(p.begin("cydprefs",true)) {p.getString("weather_station",id,sizeof(id));p.end();int n=find(id);if(n>=0)value=n;}
 selected().store(value);return value;
}
inline bool save(int value) {
 if(value<0 || value>=COUNT)return false;
 Preferences p;bool ok=p.begin("cydprefs",false);
 if(ok)ok=p.putString("weather_station",STATIONS[value].id)>0;
 p.end();char check[24]={};
 bool opened=p.begin("cydprefs",true);if(opened){p.getString("weather_station",check,sizeof(check));p.end();}
 ok=ok && opened && strcmp(check,STATIONS[value].id)==0;
 if(ok)selected().store(value);return ok;
}
}
