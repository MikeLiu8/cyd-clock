#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <esp_sntp.h>
#include <esp_netif.h>
#include <time.h>
#include <atomic>
#include "board_config.h"
#include "wifi_config.h"
#include "daily_reader.h"
// Stage9A verified bounded Wi-Fi/SNTP flow, now independent of UI/SD/touch.
class ClockService {
 public:
  bool valid=false,initialized=false,manualOffline=false;
  unsigned syncCount=0;
  uint32_t syncedAt=0;
  const char *status="CONFIG NEEDED";
  bool begin(const wifi_config::Credentials &input) {
    credentials=input;manualOffline=false;WiFi.persistent(false);WiFi.setAutoReconnect(false);
    setenv("TZ",board_config::TIMEZONE,1);tzset();
    initialized=esp_netif_init()==ESP_OK;
    if(!initialized) {status="NETWORK INIT FAILED";return false;}
    esp_sntp_set_time_sync_notification_cb([](struct timeval *) {pending().store(true);});
    retry();return true;
  }
  void retry() {
    if(!initialized) return;
    manualOffline=false;esp_sntp_stop();pending().store(false);WiFi.disconnect(false,false);
    attempts=0;attempt();
  }
  void offline() {
    if(!initialized) return;
    manualOffline=true;esp_sntp_stop();pending().store(false);WiFi.disconnect(true,false);
    set(State::Offline,"OFFLINE");
  }
  bool date(daily::Date &out) const {
    if(!valid) return false;
    time_t epoch=time(nullptr);struct tm value={};
    if(!localtime_r(&epoch,&value) || value.tm_year<124 || value.tm_year>199) return false;
    out={unsigned(value.tm_year+1900),unsigned(value.tm_mon+1),unsigned(value.tm_mday)};return true;
  }
  const char *label() const {return !valid?"等待校時":(connected()?"網絡日期":"離線走時");}
  bool connected() const {return initialized && WiFi.status()==WL_CONNECTED;}
  void report() const {
    Serial.printf("CLOCK_STATE status=%s valid=%s sync_count=%u wifi_connected=%s age_ms=%u\n",status,valid?"true":"false",syncCount,connected()?"true":"false",valid?unsigned(millis()-syncedAt):0);
    if(valid) {time_t epoch=time(nullptr);struct tm value={};localtime_r(&epoch,&value);char text[32];strftime(text,sizeof(text),"%Y-%m-%dT%H:%M:%S+08:00",&value);Serial.printf("CLOCK local=%s epoch=%lld\n",text,(long long)epoch);}
  }
  void tick() {
    if(!initialized) return;
    if(pending().exchange(false)) {
      time_t epoch=time(nullptr);struct tm value={};
      if(localtime_r(&epoch,&value) && value.tm_year>=124 && value.tm_year<=199) {
        valid=true;++syncCount;syncedAt=millis();attempts=0;set(State::Ready,"NTP SYNCED");report();
      } else fail("INVALID NTP DATE");
    }
    uint32_t now=millis();if(now-lastPoll<200) return;lastPoll=now;
    uint32_t elapsed=now-since;
    switch(state) {
      case State::Connecting:
        if(connected()) {set(State::Syncing,"NTP WAITING");configTzTime(board_config::TIMEZONE,board_config::NTP_SERVER);}
        else if(elapsed>=board_config::CONNECT_TIMEOUT_MS) fail("WIFI TIMEOUT");
        break;
      case State::Syncing:
        if(!connected()) fail("WIFI LOST DURING NTP");
        else if(elapsed>=board_config::SYNC_TIMEOUT_MS) fail("NTP TIMEOUT");
        break;
      case State::Ready:if(!connected()) {attempts=0;fail("WIFI LOST");}break;
      case State::Backoff:if(elapsed>=board_config::RETRY_MS*(attempts?attempts:1)) attempt();break;
      default:break;
    }
  }
 private:
  enum class State {Connecting,Syncing,Ready,Backoff,Failed,Offline};
  State state=State::Failed;
  wifi_config::Credentials credentials;
  unsigned attempts=0;uint32_t since=0,lastPoll=0;
  static std::atomic<bool> &pending() {static std::atomic<bool> value{false};return value;}
  void set(State next,const char *message) {state=next;status=message;since=millis();Serial.printf("NETWORK status=%s attempt=%u clock_valid=%s\n",status,attempts,valid?"true":"false");}
  void attempt() {++attempts;pending().store(false);if(WiFi.getMode()!=WIFI_AP_STA) WiFi.mode(WIFI_STA);WiFi.begin(credentials.ssid,credentials.password);set(State::Connecting,"WIFI CONNECTING");}
  void fail(const char *message) {
    esp_sntp_stop();WiFi.disconnect(false,false);Serial.printf("NETWORK_FAILURE reason=%s bounded=true clock_retained=%s\n",message,valid?"true":"false");
    set(attempts<board_config::MAX_ATTEMPTS?State::Backoff:State::Failed,attempts<board_config::MAX_ATTEMPTS?"WAIT TO RETRY":"RETRY LIMIT");
  }
};
