#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
// Bounded, lossless zero-run encoding. API/RAM Config layout stays unchanged.
// Stored header is specific to the existing little-endian ESP32 record layout.
namespace settings_codec {
constexpr size_t LIMIT=3072;
constexpr uint32_t MAGIC=0x315A4B44; // DKZ1
struct Header {uint32_t magic;uint16_t rawBytes,storedBytes;uint32_t crc;};
static_assert(sizeof(Header)==12,"Unexpected storage header layout");
inline size_t pack(const void *raw,size_t bytes,uint32_t crc,uint8_t *out,size_t capacity){
 if(!raw||!out||bytes>65535||capacity<sizeof(Header))return 0;
 const auto *p=static_cast<const uint8_t*>(raw);size_t i=0,n=sizeof(Header);
 while(i<bytes){
  size_t zeros=0;while(i+zeros<bytes&&zeros<128&&p[i+zeros]==0)++zeros;
  if(zeros>=2){if(n==capacity)return 0;out[n++]=0x80|uint8_t(zeros-1);i+=zeros;}
  else {size_t start=i;++i;while(i<bytes&&i-start<128){if(p[i]==0&&i+1<bytes&&p[i+1]==0)break;++i;}
   size_t count=i-start;if(n==capacity||count>capacity-n-1)return 0;out[n++]=uint8_t(count-1);memcpy(out+n,p+start,count);n+=count;
  }
 }
 if(n>65535)return 0;Header h{MAGIC,uint16_t(bytes),uint16_t(n),crc};memcpy(out,&h,sizeof(h));return n;
}
// Compare mode checks every restored byte against the intended Config without
// allocating a second 7.6KB Config. Decode mode is used only during startup.
inline bool restore(const uint8_t *stored,size_t bytes,void *raw,size_t capacity,uint32_t &crc,bool compare=false){
 if(!stored||!raw||bytes<sizeof(Header)||bytes>LIMIT)return false;Header h;memcpy(&h,stored,sizeof(h));
 if(h.magic!=MAGIC||h.rawBytes!=capacity||h.storedBytes!=bytes)return false;
 auto *out=static_cast<uint8_t*>(raw);size_t i=sizeof(Header),n=0;
 while(i<bytes){uint8_t tag=stored[i++];size_t count=(tag&127)+1;if(count>capacity-n)return false;
  if(tag&128){if(compare){for(size_t j=0;j<count;++j)if(out[n+j])return false;}else memset(out+n,0,count);}
  else {if(count>bytes-i)return false;if(compare){if(memcmp(out+n,stored+i,count))return false;}else memcpy(out+n,stored+i,count);i+=count;}
  n+=count;
 }
 if(n!=capacity)return false;crc=h.crc;return true;
}
}
