#pragma once
#include <stdint.h>
#include <stdio.h>
#include <initializer_list>
#include "wifi_config.h"
namespace web_credentials {
struct Form {
  char ssid[33]={}, password[65]={}, pin[7]={}, open[2]={};
};
inline int hex(char c) {
  if(c>='0' && c<='9') return c-'0';
  if(c>='a' && c<='f') return c-'a'+10;
  if(c>='A' && c<='F') return c-'A'+10;
  return -1;
}
inline bool decode(const char *s,size_t n,char *out,size_t cap) {
  size_t j=0;
  for(size_t i=0;i<n;++i) {
    unsigned char c=s[i];
    if(c=='+') c=' ';
    else if(c=='%') {
      if(i+2>=n || hex(s[i+1])<0 || hex(s[i+2])<0) return false;
      c=(hex(s[i+1])<<4)|hex(s[i+2]);i+=2;
    }
    if(c<32 || c==127 || j+1>=cap) return false;
    out[j++]=c;
  }
  out[j]=0;return true;
}
// Strict, bounded URL-encoded form: reject duplicates, unknown keys and NUL.
inline bool parse(const char *s,size_t n,Form &out) {
  if(n>512) return false;
  Form f;unsigned seen=0;size_t pos=0;
  while(pos<n) {
    size_t start=pos;while(pos<n && s[pos]!='&') ++pos;
    size_t end=pos;if(pos<n) ++pos;
    size_t eq=start;while(eq<end && s[eq]!='=') ++eq;
    if(eq==end) return false;
    char key[12];if(!decode(s+start,eq-start,key,sizeof(key))) return false;
    char *value=nullptr;size_t cap=0;unsigned bit=0;
    if(strcmp(key,"ssid")==0) {value=f.ssid;cap=sizeof(f.ssid);bit=1;}
    else if(strcmp(key,"password")==0) {value=f.password;cap=sizeof(f.password);bit=2;}
    else if(strcmp(key,"pin")==0) {value=f.pin;cap=sizeof(f.pin);bit=4;}
    else if(strcmp(key,"open")==0) {value=f.open;cap=sizeof(f.open);bit=8;}
    else return false;
    if(seen&bit || !decode(s+eq+1,end-eq-1,value,cap)) return false;
    seen|=bit;
  }
  if((seen&7)!=7 || ((seen&8) && strcmp(f.open,"1")!=0)) return false;
  out=f;return true;
}
inline bool valid(const wifi_config::Credentials &c) {
  if(!memchr(c.ssid,0,sizeof(c.ssid)) || !memchr(c.password,0,sizeof(c.password))) return false;
  for(const char *value : {c.ssid,c.password})
    for(size_t i=0;value[i];++i) if((unsigned char)value[i]<32 || value[i]==127) return false;
  char text[128];int n=snprintf(text,sizeof(text),"SSID=%s\nPASSWORD=%s\n",c.ssid,c.password);
  wifi_config::Credentials check;
  bool ok=n>0 && size_t(n)<sizeof(text) && wifi_config::parse(text,n,check)==wifi_config::Result::Okay;
  memset(text,0,sizeof(text));return ok;
}
inline bool resolve(const Form &f,const wifi_config::Credentials &old,wifi_config::Credentials &out) {
  wifi_config::Credentials c;strcpy(c.ssid,f.ssid);
  if(f.open[0]=='1') c.password[0]=0;
  else if(!f.password[0]) {
    if(strcmp(f.ssid,old.ssid)!=0) return false; // New open network needs the explicit checkbox.
    strcpy(c.password,old.password);
  }
  else strcpy(c.password,f.password);
  if(!valid(c)) {memset(&c,0,sizeof(c));return false;}
  out=c;memset(&c,0,sizeof(c));return true;
}
struct Record {uint32_t version=1;wifi_config::Credentials credentials;uint32_t checksum=0;};
inline uint32_t checksum(const wifi_config::Credentials &c) {
  uint32_t hash=2166136261u;const uint8_t *p=reinterpret_cast<const uint8_t*>(&c);
  for(size_t i=0;i<sizeof(c);++i) hash=(hash^p[i])*16777619u;
  return hash; // Accidental corruption check, not encryption/authentication.
}
inline bool validRecord(const Record &r) {return r.version==1 && r.checksum==checksum(r.credentials) && valid(r.credentials);}
}
