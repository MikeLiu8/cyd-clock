#pragma once
#include <stddef.h>
#include <stdint.h>

namespace bible_reader {
enum class Status { Found, NotFound, EmptyVerse, TooLong, ScanLimit, ReadError, InvalidUtf8, InvalidArgument };
struct Result { Status status; size_t length; size_t scanned; };

inline bool validUtf8(const char *text, size_t length) {
  size_t i = 0;
  while (i < length) {
    const uint8_t first = static_cast<uint8_t>(text[i++]);
    if (first < 0x80) { if (first == 0) return false; continue; }
    uint32_t codepoint = 0, minimum = 0;
    unsigned continuation = 0;
    if (first >= 0xc2 && first <= 0xdf) { continuation=1; codepoint=first&0x1f; minimum=0x80; }
    else if (first >= 0xe0 && first <= 0xef) { continuation=2; codepoint=first&0x0f; minimum=0x800; }
    else if (first >= 0xf0 && first <= 0xf4) { continuation=3; codepoint=first&0x07; minimum=0x10000; }
    else return false;
    if (length-i < continuation) return false;
    while (continuation--) {
      const uint8_t byte=static_cast<uint8_t>(text[i++]);
      if ((byte&0xc0)!=0x80) return false;
      codepoint=(codepoint<<6)|(byte&0x3f);
    }
    if (codepoint<minimum || codepoint>0x10ffff || (codepoint>=0xd800 && codepoint<=0xdfff)) return false;
  }
  return true;
}

// Reader.read() supplies one byte, -1 for EOF, or -2 for an I/O/timeout error.
// Only the requested verse is retained; other lines can be arbitrarily long
// within maxScanBytes. No chapter String, JSON or dynamically sized buffer.
template<class Reader>
Result readVerse(Reader &reader, uint16_t wanted, char *output,
                 size_t capacity, size_t maxScanBytes) {
  if (!output || capacity<2 || wanted==0 || maxScanBytes==0)
    return {Status::InvalidArgument,0,0};
  output[0]=0;
  enum class State { Prefix, Digits, Separator, Text, Discard };
  State state=State::Prefix;
  uint32_t number=0;
  size_t used=0, scanned=0;
  bool matched=false;
  const auto finish = [&]() -> Result {
    output[used]=0;
    if (!used) return {Status::EmptyVerse,0,scanned};
    if (!validUtf8(output,used)) { output[0]=0; return {Status::InvalidUtf8,0,scanned}; }
    return {Status::Found,used,scanned};
  };
  for (;;) {
    const int c=reader.read();
    if (c<-1) { output[0]=0; return {Status::ReadError,0,scanned}; }
    if (c==-1) {
      if (matched || (state==State::Digits && number==wanted)) return finish();
      return {Status::NotFound,0,scanned};
    }
    if (scanned>=maxScanBytes) { output[0]=0; return {Status::ScanLimit,0,scanned}; }
    ++scanned;
    if (scanned==1 && c==0xef) {
      if (maxScanBytes-scanned<2) return {Status::ScanLimit,0,scanned};
      const int b=reader.read(), d=reader.read(); scanned+=2;
      if (b<-1 || d<-1) return {Status::ReadError,0,scanned};
      if (b!=0xbb || d!=0xbf) return {Status::InvalidUtf8,0,scanned};
      continue;
    }
    if (c=='\r') continue; // LF and CRLF files share the same verse bytes.
    if (c=='\n') {
      if (matched || (state==State::Digits && number==wanted)) return finish();
      state=State::Prefix; number=0; matched=false; continue;
    }
    const bool space=c==' ' || c=='\t';
    if (state==State::Discard) continue;
    if (state==State::Prefix) {
      if (space) continue;
      if (c>='0' && c<='9') { number=c-'0'; state=State::Digits; }
      else state=State::Discard;
      continue;
    }
    if (state==State::Digits) {
      if (c>='0' && c<='9') {
        number=number*10+(c-'0');
        if (number>65535) state=State::Discard;
      } else if (space) {
        matched=number==wanted;
        state=matched ? State::Separator : State::Discard;
      } else state=State::Discard; // e.g. 16x cannot match verse 16.
      continue;
    }
    if (state==State::Separator) {
      if (space) continue;
      state=State::Text;
    }
    if (used+1>=capacity) { output[0]=0; return {Status::TooLong,0,scanned}; }
    output[used++]=static_cast<char>(c);
  }
}

inline const char *statusName(Status status) {
  switch (status) {
    case Status::Found:return "FOUND";
    case Status::NotFound:return "VERSE_NOT_FOUND";
    case Status::EmptyVerse:return "EMPTY_VERSE";
    case Status::TooLong:return "VERSE_TOO_LONG";
    case Status::ScanLimit:return "SCAN_LIMIT";
    case Status::ReadError:return "READ_ERROR_OR_TIMEOUT";
    case Status::InvalidUtf8:return "INVALID_UTF8";
    default:return "INVALID_ARGUMENT";
  }
}
} // namespace bible_reader
