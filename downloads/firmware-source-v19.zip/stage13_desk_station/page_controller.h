#pragma once
#include <stdint.h>
class PageController {
 public:
  static constexpr uint8_t COUNT=4;
  static constexpr uint8_t AUTO_COUNT=3;
  static constexpr uint32_t INTERVAL_MS=12000, PAUSE_MS=40000;
  uint8_t page() const { return current; }
  uint32_t intervalMs=12000;
  bool automatic=true, pinned=false, paused=false;
  void select(uint8_t value) { current=value%COUNT; }
  void next() { current=(current+1)%COUNT; }
  void nextAutomatic() { if(current<AUTO_COUNT)current=(current+1)%AUTO_COUNT; }
  void previous() { current=(current+COUNT-1)%COUNT; }
  void drawn(uint32_t now) { displayedAt=now; }
  void touched(uint32_t now) { paused=true; touchedAt=now; }
  bool resume(uint32_t now) {
    if(paused && uint32_t(now-touchedAt)>=PAUSE_MS) {paused=false;return true;}
    return false;
  }
  bool due(uint32_t now) const {
    return current<AUTO_COUNT && automatic && !pinned && !paused && uint32_t(now-displayedAt)>=intervalMs;
  }
 private:
  uint8_t current=0;
  uint32_t displayedAt=0,touchedAt=0;
};
