#pragma once
#include "marquee_core.h"
// Optional daily content, loaded only inside the existing SD/network gate.
// MQF1 is the existing compact glyph container; text CRC binds the question.
class ReflectionQuestion {
 static constexpr unsigned MAX_CHARS=36, FILE_BYTES=marquee::HEADER+MAX_CHARS*marquee::RECORD;
 uint8_t buffer[FILE_BYTES]={};char question[128]={};
 marquee::Asset asset;marquee::Text text;unsigned split=0;
 bool ready=false;const char *problem="等候今日反思";
 bool layout(){
  unsigned width=0;split=text.count;
  for(unsigned i=0;i<text.count;++i){unsigned advance=text.advance(i,asset);if(width+advance>272){split=i;break;}width+=advance;}
  // A closing mark stays with a preceding character instead of starting a row.
  if(split<text.count&&split){unsigned k=text.indices[split];unsigned cp=k<asset.count?marquee::u16(asset.record(k)):0;
   if(cp==0xff0c||cp==0x3002||cp==0xff1f||cp==0xff01||cp==0xff1b||cp==0xff1a||cp==0x3001||cp==0x300d||cp==0xff09)--split;}
  width=0;for(unsigned i=split;i<text.count;++i){width+=text.advance(i,asset);if(width>272)return false;}return split>0;
 }
 public:
 bool valid()const{return ready;}
 const char *error()const{return problem;}
 void clear(){ready=false;question[0]=0;asset={};text={};split=0;problem="等候今日反思";}
 void load(const DailyContent &d){
  clear();problem="今日反思未提供";if(d.state!=ContentState::Available)return;
  char path[48];snprintf(path,sizeof(path),"/reflections/%02u-%02u.txt",d.date.month,d.date.day);
  File f=SD.open(path,FILE_READ);if(!f||f.isDirectory()){f.close();return;}
  size_t n=f.size();if(!n||n>=sizeof(question)||f.read(reinterpret_cast<uint8_t*>(question),n)!=n){f.close();problem="反思資料損壞";return;}f.close();question[n]=0;
  for(unsigned i=0;i<n;++i)if(uint8_t(question[i])<32){problem="反思資料損壞";return;}
  uint32_t crc=marquee::crc(reinterpret_cast<const uint8_t*>(question),n);
  snprintf(path,sizeof(path),"/fonts/reflection/%02u-%02u.mqf",d.date.month,d.date.day);
  f=SD.open(path,FILE_READ);if(!f||f.isDirectory()){f.close();problem="反思字體未準備";return;}
  n=f.size();bool read=n<=sizeof(buffer)&&f.read(buffer,n)==n;f.close();
  if(!read||!asset.validate(buffer,n,d.date.month,d.date.day,d.ref.book,d.ref.chapter,d.ref.verse,crc)||asset.count>MAX_CHARS){problem="反思字體損壞";return;}
  if(!text.append(question,asset)||!text.count||text.count>MAX_CHARS||!layout()){problem="反思字形或長度錯誤";return;}
  ready=true;problem="";
  Serial.printf("REFLECTION ready=true chars=%u glyphs=%u lines=%u bytes=%u ram=%u\n",text.count,asset.count,split==text.count?1:2,unsigned(n),unsigned(sizeof(*this)));
 }
 void paint(uint16_t colour){
  if(!ready)return;unsigned x=24;int y=168;
  for(unsigned i=0;i<text.count;++i){if(i==split){x=24;y=194;}unsigned k=text.indices[i];if(k<asset.count)lcd.drawBitmap(x,y,asset.record(k)+4,16,18,colour);x+=text.advance(i,asset);}
 }
};
static_assert(sizeof(ReflectionQuestion)+128<=2048,"Daily reflection state and temporary path/IO reserve must fit 2KB");
