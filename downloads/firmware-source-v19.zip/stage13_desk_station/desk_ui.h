#pragma once
#include "desk_font.h"
#include "home_font.h"
#include "qr_url.h"
#include "settings_logo.h"
desk::UiConfig uiConfig={};uint32_t uiRevision=0,uiTickAt=0,lastDynamicValue=~0u;bool settingsShowing=false,forecastShowing=false,isNight=false,pwmReady=false,biblePending=false;uint16_t canvasBG=TFT_WHITE,canvasFG=TFT_BLACK,canvasAccent=TFT_BLUE;int touchPressY=0,touchPressX=0;
bool timerRunning=false,timerComplete=false,timerEngaged=false;uint16_t timerMinutes=10;uint32_t deskTimerDeadline=0,timerRemainingMs=600000;
uint32_t pinNoticeAt=0;char settingsQrUrl[64]={};UrlQr urlQr;bool qrReady=false;
const char *pageNames[]={"首頁","聖經","交通","工具"};
void drawPage(const char *trigger);
void tc(const char *text,int x,int y,uint16_t colour){lcd.unloadFont();activeFont=0;size_t i=0;while(text[i]&&x<304){uint32_t cp=static_cast<uint8_t>(text[i++]);if(cp>=128){unsigned n=cp<224?1:cp<240?2:3;cp&=(1u<<(6-n))-1;bool ok=true;while(n--){unsigned char v=text[i];if(v<128||v>=192){ok=false;break;}++i;cp=(cp<<6)|(v&63);}if(!ok)cp='?';}if(cp<128){char s[2]={char(cp),0};lcd.setTextColor(colour,canvasBG);lcd.drawString(s,x,y,2);x+=lcd.textWidth(s,2);}else{size_t pos=0;while(pos<sizeof(DESK_GLYPHS)/sizeof(DESK_GLYPHS[0])&&DESK_GLYPHS[pos]!=cp)++pos;if(pos<sizeof(DESK_GLYPHS)/sizeof(DESK_GLYPHS[0]))lcd.drawBitmap(x,y,DESK_BITMAPS[pos],16,18,colour);else {lcd.drawRect(x+2,y+2,12,12,colour);}x+=16;}}}
const char *weatherLabel(int icon){switch(icon){case 50:return "陽光充沛";case 51:return "間有陽光";case 52:return "短暫陽光";case 53:return "間有陽光幾陣驟雨";case 54:return "短暫陽光有驟雨";case 60:return "多雲";case 61:return "密雲";case 62:return "微雨";case 63:return "雨";case 64:return "大雨";case 65:return "雷暴";case 76:return "大致多雲（夜間）";case 77:return "天色大致良好（夜間）";case 80:return "大風";case 81:return "乾燥";case 82:return "潮濕";case 83:return "霧";case 84:return "薄霧";case 85:return "煙霞";case 90:return "熱";case 91:return "暖";case 92:return "涼";case 93:return "冷";default:return icon>=70&&icon<=75?"天色良好（夜間）":"暫未取得資料";}}
void weatherIcon(int code,int x=258,int y=82){
 uint16_t gold=uiConfig.settings.colour?lcd.color565(isNight?243:154,isNight?201:101,isNight?117:14):canvasFG;
 if(code>=70&&code<=75){lcd.fillCircle(x,y,20,gold);lcd.fillCircle(x+8,y-7,19,canvasBG);}
 else if(code>=50&&code<=54){bool showers=code>=53;int sx=x-(showers?8:0),sy=y-(showers?6:0);lcd.fillCircle(sx,sy,showers?10:13,gold);
  for(int i=0;i<8;++i){float a=i*0.785398f;lcd.drawLine(sx+int(cosf(a)*(showers?14:18)),sy+int(sinf(a)*(showers?14:18)),sx+int(cosf(a)*(showers?20:26)),sy+int(sinf(a)*(showers?20:26)),gold);}
  if(showers){lcd.fillCircle(x-9,y+5,9,canvasAccent);lcd.fillCircle(x+5,y,12,canvasAccent);lcd.fillRoundRect(x-18,y+4,42,14,6,canvasAccent);for(int i=0;i<3;++i)lcd.drawLine(x-13+i*14,y+24,x-17+i*14,y+32,canvasAccent);}
 }else {lcd.fillCircle(x-12,y,13,canvasAccent);lcd.fillCircle(x+2,y-9,17,canvasAccent);lcd.fillRoundRect(x-24,y,50,16,8,canvasAccent);if(code>=62&&code<=65)for(int i=0;i<3;++i)lcd.drawLine(x-15+i*16,y+24,x-19+i*16,y+32,canvasAccent);}
}
uint32_t remaining(){if(!timerRunning)return timerRemainingMs;int32_t delta=static_cast<int32_t>(deskTimerDeadline-millis());return delta>0?uint32_t(delta):0;}
void resetTimer(){timerRunning=false;timerComplete=false;timerEngaged=false;timerRemainingMs=60000u*timerMinutes;}
void openSettings(){forecastShowing=false;settingsShowing=true;pinNoticeAt=0;qrReady=false;settingsQrUrl[0]=0;pages.touched(millis());drawPage("touch_settings");}
void toolAction(unsigned cmd){
 settingsShowing=false;forecastShowing=false;pinNoticeAt=0;
 {pages.select(3);if(cmd==4){if(timerRunning){timerRemainingMs=remaining();timerRunning=false;}else {if(!timerRemainingMs)resetTimer();deskTimerDeadline=millis()+timerRemainingMs;timerRunning=true;timerComplete=false;}timerEngaged=true;}else if(cmd==5)resetTimer();}
 pages.touched(millis());drawPage("tool_action");
}
void refreshDeskConfig(){
 if(uiRevision==desk::revision().load())return;bool first=uiRevision==0;unsigned previousMinutes=uiConfig.settings.countMinutes;uint32_t snapshotRevision=0;if(!desk::copy(uiConfig,&snapshotRevision))return;uiRevision=snapshotRevision;pages.automatic=uiConfig.settings.automatic;pages.intervalMs=uiConfig.settings.interval*1000u;
 if(first||previousMinutes!=uiConfig.settings.countMinutes){timerMinutes=uiConfig.settings.countMinutes;if(!timerEngaged)resetTimer();}
}
bool nightPeriod(){if(!networkClock.valid||!uiConfig.settings.nightEnabled||uiConfig.settings.nightStart==uiConfig.settings.nightEnd)return false;tm t;time_t now=time(nullptr);localtime_r(&now,&t);unsigned n=t.tm_hour*60+t.tm_min;return uiConfig.settings.nightStart<uiConfig.settings.nightEnd?n>=uiConfig.settings.nightStart&&n<uiConfig.settings.nightEnd:n>=uiConfig.settings.nightStart||n<uiConfig.settings.nightEnd;}
void palette(){isNight=!webConfig.isAP()&&nightPeriod();canvasBG=isNight?lcd.color565(16,30,34):lcd.color565(252,251,243);canvasFG=isNight?lcd.color565(223,223,205):lcd.color565(35,61,54);canvasAccent=uiConfig.settings.colour?(isNight?lcd.color565(146,200,232):lcd.color565(34,95,135)):canvasFG;if(!uiConfig.settings.colour){canvasBG=isNight?TFT_BLACK:TFT_WHITE;canvasFG=isNight?TFT_WHITE:TFT_BLACK;}if(pwmReady&&!ledcWrite(board_config::BACKLIGHT,webConfig.isAP()?255:(isNight?uiConfig.settings.nightBrightness:uiConfig.settings.dayBrightness))){ledcDetach(board_config::BACKLIGHT);pinMode(board_config::BACKLIGHT,OUTPUT);digitalWrite(board_config::BACKLIGHT,HIGH);pwmReady=false;Serial.println("BACKLIGHT pwm_write=FAIL fallback=GPIO_HIGH");}}
void basic(int x,int y,const char *s,int font=2,uint16_t colour=0,int scale=1){lcd.unloadFont();activeFont=0;lcd.setTextColor(colour?colour:canvasFG,canvasBG);lcd.setTextSize(scale);lcd.drawString(s,x,y,font);lcd.setTextSize(1);}
// One direct settings entry; no page menu or redundant settings categories.
void drawLanSettings(){
 char address[64];snprintf(address,sizeof(address),"http://%s/",webConfig.ip().c_str());
 bool linkReady=webConfig.ready()&&networkClock.connected();if(!linkReady)qrReady=false;
 if(linkReady&&(!qrReady||strcmp(address,settingsQrUrl))){strcpy(settingsQrUrl,address);qrReady=urlQr.encode(address);}
 tc("網頁設定",16,10,canvasAccent);ignite_logo::draw(lcd,240,2);basic(16,38,address,2);
 if(qrReady){constexpr int s=3,x=16,y=66;lcd.fillRect(x,y,(UrlQr::SIZE+8)*s,(UrlQr::SIZE+8)*s,TFT_WHITE);for(int row=0;row<UrlQr::SIZE;++row)for(int col=0;col<UrlQr::SIZE;++col)if(urlQr.dark(col,row))lcd.fillRect(x+(col+4)*s,y+(row+4)*s,s,s,TFT_BLACK);}else tc("未連線",32,116,canvasFG);
 basic(172,72,"PIN",2);basic(172,96,webConfig.pin(),4);tc("手機同一網絡",172,140,canvasFG);tc("掃碼後輸入PIN",172,164,canvasFG);
 lcd.drawRoundRect(168,198,136,34,4,canvasAccent);tc("返回倒數",204,206,canvasFG);
}
void drawTicker(){
 uint16_t bg=isNight?lcd.color565(8,18,21):(uiConfig.settings.colour?lcd.color565(35,61,54):TFT_BLACK),fg=isNight?canvasFG:lcd.color565(252,251,243);
 lcd.fillRect(0,208,320,4,bg);lcd.fillRect(0,236,320,4,bg);lcd.fillRect(0,212,16,24,bg);
 if(homeMarquee.valid()){homeMarquee.paint(fg,bg);if(homeMarquee.motion.paused){lcd.fillRect(3,218,3,10,fg);lcd.fillRect(9,218,3,10,fg);}}
 else {lcd.fillRect(16,212,304,24,bg);uint16_t saved=canvasBG;canvasBG=bg;tc(homeMarquee.error(),16,215,fg);canvasBG=saved;}
}
void sevenDigit(int x,int y,int digit){
 constexpr uint8_t masks[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};uint8_t bits=digit<0?0x40:masks[digit];
 const int rects[7][4]={{6,0,32,6},{38,6,6,30},{38,42,6,30},{6,72,32,6},{0,42,6,30},{0,6,6,30},{6,36,32,6}};
 for(int i=0;i<7;++i)if(bits&(1<<i))lcd.fillRoundRect(x+rects[i][0],y+rects[i][1],rects[i][2],rects[i][3],2,canvasFG);
}
void drawHomeClock(bool force){
 static int lastMinute=-2,lastSecond=-2;tm t={};time_t epoch=time(nullptr);bool valid=networkClock.valid;if(valid)localtime_r(&epoch,&t);
 int minute=valid?t.tm_hour*60+t.tm_min:-1,second=valid?t.tm_sec:-1;
 if(force||minute!=lastMinute){lcd.fillRect(12,40,220,82,canvasBG);int digits[4]={valid?t.tm_hour/10:-1,valid?t.tm_hour%10:-1,valid?t.tm_min/10:-1,valid?t.tm_min%10:-1};const int xs[]={12,64,128,180};for(int i=0;i<4;++i)sevenDigit(xs[i],42,digits[i]);lcd.fillCircle(116,69,3,canvasFG);lcd.fillCircle(116,96,3,canvasFG);lastMinute=minute;}
 if(force||second!=lastSecond){lcd.fillRect(258,90,50,32,canvasBG);char b[8];if(valid)snprintf(b,sizeof(b),"%02d",second);else strcpy(b,"--");basic(262,92,b,4);lastSecond=second;}
}
// Bounded native glyphs are RLE-compressed in Flash; draw runs directly, no canvas.
const HomeGlyph *homeGlyph(uint32_t cp,uint8_t size){for(const auto &g:HOME_GLYPHS)if(g.code==cp&&g.size==size)return &g;return nullptr;}
int homeWidth(const char *text,uint8_t size){size_t offset=0;int width=0;while(text[offset]){const auto *g=homeGlyph(nextCodepoint(text,offset),size);width+=g?g->width:size;}return width;}
void homeText(const char *text,int x,int y,uint8_t size,uint16_t colour,int right=308){
 lcd.unloadFont();activeFont=0;size_t offset=0;unsigned height=size==24?29:size==18?24:size+4;lcd.startWrite();
 while(text[offset]&&x<right){const auto *g=homeGlyph(nextCodepoint(text,offset),size);if(!g){lcd.drawRect(x,y+2,size,size,colour);x+=size;continue;}
  unsigned pixel=0,pos=g->offset,total=g->width*height;
  while(pixel<total){uint8_t run=pgm_read_byte(HOME_BITS+pos++);unsigned length=min(unsigned((run&127)+1),total-pixel);
   if(run&128){while(length){unsigned col=pixel%g->width,n=min(length,unsigned(g->width)-col);int visible=min(int(n),right-x-int(col));if(visible>0)lcd.drawFastHLine(x+col,y+pixel/g->width,visible,colour);pixel+=n;length-=n;}}
   else pixel+=length;
  }
  x+=g->width;
 }
 lcd.endWrite();
}
void drawHome(){
 auto w=weatherService.snapshot();int station=weather_prefs::selected().load();bool valid=w.valid&&w.station==station;char b[64];
 uint16_t secondary=uiConfig.settings.colour?(isNight?lcd.color565(171,184,174):lcd.color565(97,113,102)):canvasFG;
 uint16_t rule=uiConfig.settings.colour?(isNight?lcd.color565(58,77,76):lcd.color565(203,213,201)):canvasFG;
 tc(valid?weatherLabel(w.icon):"天氣暫未取得資料",12,8,canvasAccent);
 snprintf(b,sizeof(b),valid?"%.0f%%":"--%%",w.humidity);lcd.unloadFont();activeFont=0;int humidityX=308-lcd.textWidth(b,4);lcd.fillCircle(humidityX-15,20,6,canvasAccent);for(int row=0;row<=10;++row){int half=(row+1)/2;lcd.drawFastHLine(humidityX-15-half,8+row,2*half+1,canvasAccent);}basic(humidityX,6,b,4);
 drawHomeClock(true);if(valid)weatherIcon(w.icon,281,57);
 const char *status=!networkClock.connected()?"離線":!valid?"等候天氣":time(nullptr)-w.reportEpoch>7200?"舊資料":w.status==WeatherService::Status::Error?"更新失敗":"";
 if(status[0])tc(status,12,121,canvasFG);
 lcd.drawFastHLine(12,140,296,rule);
 if(current.date.year>=2024){snprintf(b,sizeof(b),"%u月%u日",current.date.month,current.date.day);homeText(b,12,149,24,canvasFG,164);const char *days[]={"日","一","二","三","四","五","六"};snprintf(b,sizeof(b),"週%s",days[daily::weekday(current.date)]);homeText(b,12,181,20,secondary,164);}else tc("日期未設定",12,154,canvasFG);
 snprintf(b,sizeof(b),valid?"%.1f":"--",w.temperature);int unit=homeWidth("°C",18);homeText(b,308-unit-3-homeWidth(b,40),154,40,canvasFG);homeText("°C",308-unit,157,18,canvasFG);
 drawTicker();
}
void drawForecast(){
 auto f=weatherService.forecastSnapshot();time_t now=time(nullptr);
 uint16_t secondary=uiConfig.settings.colour?(isNight?lcd.color565(171,184,174):lcd.color565(97,113,102)):canvasFG;
 uint16_t rule=uiConfig.settings.colour?(isNight?lcd.color565(58,77,76):lcd.color565(203,213,201)):canvasFG;
 tc("香港預報",12,12,canvasAccent);tc("天文台",112,12,secondary);
 lcd.drawRoundRect(244,6,64,34,4,canvasAccent);tc("返回",260,14,canvasFG);lcd.drawFastHLine(12,46,296,rule);
 for(unsigned i=0;i<2;++i){int y=52+i*82;uint32_t key=WeatherService::dateKey(now,i+1);const WeatherService::ForecastDay *d=nullptr;
  if(f.valid)for(const auto &v:f.days)if(v.date==key)d=&v;
  tc(i?"後天":"明天",12,y+4,canvasFG);char text[32];
  if(key)snprintf(text,sizeof(text),"%02u/%02u",unsigned(key/100%100),unsigned(key%100));else strcpy(text,"--/--");basic(12,y+32,text,2,secondary);
  if(d){weatherIcon(d->icon,107,y+32);snprintf(text,sizeof(text),"%.0f-%.0f",d->low,d->high);basic(160,y+4,text,4);homeText("°C",274,y+9,18,canvasFG);tc(weatherLabel(d->icon),144,y+46,canvasAccent);}
  else {basic(168,y+4,"-- / --",4,secondary);tc("未取得預報",144,y+46,secondary);}
  if(i==0)lcd.drawFastHLine(12,130,296,rule);
 }
 lcd.drawFastHLine(12,213,296,rule);
 char updated[24];if(f.valid)snprintf(updated,sizeof(updated),"%.5s %.5s",f.reportTime+5,f.reportTime+11);else strcpy(updated,"--/-- --:--");basic(12,219,updated,2,secondary);
 bool stale=f.valid&&(!networkClock.connected()||f.status==WeatherService::Status::Error||now-f.reportEpoch>86400);
 tc(!networkClock.connected()?"離線":stale?"舊資料":f.status==WeatherService::Status::Fetching?"更新中":f.status==WeatherService::Status::Error?"更新失敗":"",224,219,canvasFG);
}
// Reduce the already validated RAM-cached VLW glyphs. Area averaging keeps
// small strokes smooth; no extra SD font, Sprite, bitmap cache or heap buffer.
int bibleScale(int value,unsigned source,unsigned target){return value>=0?(value*int(target)+int(source)/2)/int(source):-((-value*int(target)+int(source)/2)/int(source));}
void bibleText(const char *text,int x,int y,uint8_t source,uint8_t target,uint16_t colour){
 if(!target||target>source||!useFont(source))return;
 size_t offset=0;lcd.startWrite();
 while(text[offset]&&x<296){
  uint32_t cp=nextCodepoint(text,offset);if(cp==32){x+=bibleScale(lcd.gFont.spaceWidth,source,target);continue;}
  uint16_t k;if(!lcd.getUnicodeIndex(cp,&k)){lcd.drawRect(x,y+4,target,target,colour);x+=target;continue;}
  unsigned sw=lcd.gWidth[k],sh=lcd.gHeight[k];
  unsigned dw=(sw*target+source-1)/source,dh=(sh*target+source-1)/source;
  const uint8_t *bitmap=lcd.gFont.gArray+lcd.gBitmap[k];
  int left=x+bibleScale(lcd.gdX[k],source,target),top=y+bibleScale(int(lcd.gFont.maxAscent)-lcd.gdY[k],source,target);
  for(unsigned row=0;row<dh;++row)for(unsigned col=0;col<dw;++col){
   unsigned a=col*source,b=min(a+source,sw*unsigned(target)),c=row*source,d=min(c+source,sh*unsigned(target));
   uint32_t sum=0;
   for(unsigned sy=c/target;sy*target<d;++sy)for(unsigned sx=a/target;sx*target<b;++sx){
    unsigned wx=min(b,(sx+1)*target)-max(a,sx*target),wy=min(d,(sy+1)*target)-max(c,sy*target);
    sum+=uint32_t(bitmap[sy*sw+sx])*wx*wy;
   }
   uint8_t alpha=(sum+source*source/2)/(source*source);
   if(alpha&&left+int(col)>=24&&left+int(col)<296&&top+int(row)>=0&&top+int(row)<240)lcd.drawPixel(left+col,top+row,lcd.alphaBlend(alpha,colour,canvasBG));
  }
  x+=bibleScale(lcd.gxAdvance[k],source,target);
 }
 lcd.endWrite();
}
void drawBible(){
 biblePending=false;if(ESP.getFreeHeap()<70000){biblePending=true;tc("正在更新資料",24,88,canvasFG);return;}
 uint16_t secondary=uiConfig.settings.colour?(isNight?lcd.color565(171,184,174):lcd.color565(97,113,102)):canvasFG;
 uint16_t rule=uiConfig.settings.colour?(isNight?lcd.color565(58,77,76):lcd.color565(203,213,201)):canvasFG;
 bibleText(current.referenceText,24,22,16,12,secondary);
 bibleText(current.lines[0],24,56,24,20,canvasFG);bibleText(current.lines[1],24,90,24,20,canvasFG);
 lcd.drawFastHLine(24,142,272,rule);lcd.drawFastHLine(24,142,40,canvasAccent);
 uint16_t questionColour=uiConfig.settings.colour?(isNight?lcd.color565(146,200,232):lcd.color565(34,78,120)):canvasFG;
 if(reflectionQuestion.valid())reflectionQuestion.paint(questionColour);else tc(reflectionQuestion.error(),24,168,secondary);
}
// Native16px semibold traffic glyphs: preserve strokes instead of subsampling.
size_t busGlyph(uint32_t cp){size_t i=0;while(i<sizeof(BUS_GLYPHS)/sizeof(BUS_GLYPHS[0])&&BUS_GLYPHS[i]!=cp)++i;return i;}
int busWidth(const char *text){size_t off=0;int width=0;while(text[off]){uint32_t cp=nextCodepoint(text,off);size_t i=busGlyph(cp);width+=i<sizeof(BUS_GLYPHS)/sizeof(BUS_GLYPHS[0])?BUS_ADVANCE[i]:16;}return width;}
void busText(const char *text,int x,int y,uint16_t colour,int right=308){
 lcd.unloadFont();activeFont=0;size_t offset=0;
 while(text[offset]&&x<right){uint32_t cp=nextCodepoint(text,offset);size_t i=busGlyph(cp);int advance=i<sizeof(BUS_GLYPHS)/sizeof(BUS_GLYPHS[0])?BUS_ADVANCE[i]:16;if(x+advance>right)break;
 if(i<sizeof(BUS_GLYPHS)/sizeof(BUS_GLYPHS[0]))lcd.drawBitmap(x,y,BUS_BITMAPS[i],16,18,colour);
 else {size_t j=0;while(j<sizeof(DESK_GLYPHS)/sizeof(DESK_GLYPHS[0])&&DESK_GLYPHS[j]!=cp)++j;if(j<sizeof(DESK_GLYPHS)/sizeof(DESK_GLYPHS[0]))lcd.drawBitmap(x,y,DESK_BITMAPS[j],16,18,colour);else lcd.drawRect(x,y+2,12,12,colour);}
 x+=advance;}
}
void busLine(int x,int y,int width,const uint8_t *image,const char *text,uint16_t colour,const uint8_t *fallback=nullptr){
 // Both formats occupy the existing648byte slot. CYD13 labels carry an8byte
 // header and a128px-wide bitmap; legacy288x18 images remain readable.
 bool styled=desk::styledImage(image,false)||desk::styledImage(image,true);
 // All saved styled labels use the same browser font. Embedded defaults are
 // only a fallback for old/missing bitmaps, never an override of saved labels.
 if(!styled&&fallback){image=fallback;styled=desk::styledImage(image,false)||desk::styledImage(image,true);}
 unsigned height=styled?image[5]:18,stride=styled?16:36;const uint8_t *bits=image+(styled?8:0);
 bool any=false;lcd.startWrite();for(unsigned row=0;row<height;++row){unsigned col=0;while(col<unsigned(width)){while(col<unsigned(width)&&!(bits[row*stride+col/8]&(0x80>>(col%8))))++col;unsigned start=col;while(col<unsigned(width)&&(bits[row*stride+col/8]&(0x80>>(col%8))))++col;if(col>start){any=true;lcd.drawFastHLine(x+start,y+row,col-start,colour);}}}lcd.endWrite();if(!any)busText(text,x,y,colour,x+width);
}
void drawBus(){
 auto all=weatherService.extras.snapshot();time_t now=time(nullptr);bool offline=!networkClock.connected();char text[48];
 uint16_t rule=uiConfig.settings.colour?(isNight?lcd.color565(58,77,76):lcd.color565(203,213,201)):canvasFG;
 for(unsigned i=0;i<3;++i){int y=i*80;const auto &b=desk::slot(uiConfig,i);const auto &e=all.slots[i];bool valid=e.busValid&&e.busRevision==uiRevision;
  bool old=offline||(valid&&(now-e.busEpoch>180||e.busError[0]));bool filled=b.route[0];
  lcd.drawRoundRect(12,y+18,64,44,3,canvasFG);if(filled)lcd.fillRoundRect(12,y+18,64,44,3,canvasFG);
  lcd.unloadFont();activeFont=0;int font=lcd.textWidth(b.route,4)<=60?4:2;const char *route=filled?b.route:"+";lcd.setTextColor(filled?canvasBG:canvasFG,filled?canvasFG:canvasBG);lcd.drawString(route,12+(64-lcd.textWidth(route,font))/2,y+26,font);
  if(!filled){busText("尚未收藏",88,y+12,canvasFG);busText("手機選收藏",88,y+42,canvasFG);basic(270,y+14,"--",4,canvasFG);}
  else {
   uint16_t secondary=uiConfig.settings.colour?(isNight?lcd.color565(171,184,174):lcd.color565(97,113,102)):canvasFG;
   lcd.drawBitmap(88,y+12,BUS_TOWARDS_IMAGE,16,16,secondary);
   busLine(104,y+8,94,b.destinationImage,b.destination,canvasFG,strcmp(b.destination,"航天城")==0?DEFAULT_COMPACT_DEST_IMAGE:nullptr);
   busLine(88,y+42,110,b.stopImage,b.stopName,secondary,strcmp(b.stopName,"大埔頭總站 (TP975)")==0?DEFAULT_COMPACT_STOP_IMAGE:nullptr);
   unsigned minutes[3]={},count=0;if(valid)for(unsigned j=0;j<e.etaCount&&count<3;++j){time_t delta=e.etas[j]-now;if(delta< -60)continue;minutes[count++]=delta<=0?0:unsigned((delta+59)/60);}
   if(count){if(!minutes[0])busText("即將到站",244,y+16,canvasFG);else {snprintf(text,sizeof(text),"%u",minutes[0]);int f=minutes[0]>999?2:minutes[0]>99?4:6;lcd.unloadFont();activeFont=0;basic(272-lcd.textWidth(text,f)-4,y+7,text,f,canvasFG);busText("分鐘",276,y+35,canvasFG);}
    char next[24],second[10],third[10];if(count>1)snprintf(second,sizeof(second),"%u",minutes[1]);else strcpy(second,"--");if(count>2)snprintf(third,sizeof(third),"%u",minutes[2]);else strcpy(third,"--");snprintf(next,sizeof(next),"%s/%s",second,third);
    int x=288-busWidth(next);if(old)busText("舊",x-16,y+60,canvasFG);busText(next,x,y+60,old?canvasFG:canvasAccent);busText("分",292,y+60,old?canvasFG:canvasAccent);
   }else {basic(266,y+14,"--",4,canvasFG);busText(offline?"離線":valid?"暫無預報":e.busError[0]?"更新失敗":"正在查詢",244,y+60,canvasFG);}
  }
  if(i<2)lcd.drawFastHLine(12,y+79,296,rule);
 }
}
void drawCountdownValue(){uint32_t sec=(remaining()+999)/1000;char b[20];snprintf(b,sizeof(b),"%02u:%02u",unsigned(sec/60),unsigned(sec%60));lcd.unloadFont();activeFont=0;lcd.setTextSize(2);int x=(320-lcd.textWidth(b,6))/2;lcd.setTextSize(1);lcd.fillRect(16,38,288,100,canvasBG);basic(x,40,b,6,0,2);}
void drawTools(){
 tc(timerComplete?"完成":timerRunning?"倒數中":timerEngaged?"已暫停":"準備倒數",16,12,canvasAccent);drawCountdownValue();
 const unsigned minutes[]={5,10,15,30};for(unsigned i=0;i<4;++i){int x=16+i*74;lcd.drawRoundRect(x,142,66,36,5,canvasAccent);char b[8];snprintf(b,sizeof(b),"%u min",minutes[i]);basic(x+(66-lcd.textWidth(b,2))/2,150,b,2,timerRunning?canvasFG:canvasAccent);}
 const char *labels[]={timerRunning?"暫停":"開始","重設","設定"};for(unsigned i=0;i<3;++i){lcd.drawRoundRect(16+i*98,194,92,38,5,canvasAccent);tc(labels[i],46+i*98,204,canvasFG);}
}
void drawDeskPage(){palette();lcd.unloadFont();activeFont=0;lcd.fillScreen(canvasBG);lcd.setTextDatum(TL_DATUM);lcd.setTextWrap(false,false);lcd.setTextSize(1);if(settingsShowing)drawLanSettings();else if(forecastShowing)drawForecast();else switch(pages.page()){case 0:drawHome();break;case 1:drawBible();break;case 2:drawBus();break;case 3:drawTools();break;}}
void deskLongPress(){
 if(webConfig.isAP()||settingsShowing||forecastShowing||touchPressX<106||touchPressX>214)return;
 pages.pinned=!pages.pinned;pinNoticeAt=millis();
 Serial.printf("TOUCH_PIN page=%u pinned=%s\n",pages.page()+1,pages.pinned?"true":"false");
 drawPage("touch_pin");
 lcd.fillRoundRect(80,96,160,32,5,canvasBG);lcd.drawRoundRect(80,96,160,32,5,canvasAccent);
 tc(pages.pinned?"已固定本頁":"已解除固定",112,103,canvasFG);
}
void deskTap(){
 int x=touchPressX,y=touchPressY;
 if(forecastShowing){if(x>=244&&x<308&&y>=6&&y<40){forecastShowing=false;pages.touched(millis());drawPage("forecast_back");}return;}
 if(settingsShowing){
  if(x>=168&&x<304&&y>=198&&y<232){settingsShowing=false;pages.select(3);pages.touched(millis());drawPage("settings_back");}return;
 }
 if(pages.page()==0&&y>=208){homeMarquee.toggle();drawTicker();return;}
 if(pages.page()==0&&x>=248&&y>=32&&y<90){forecastShowing=true;homeMarquee.tick(false);pages.touched(millis());drawPage("forecast_open");return;}
 if(pages.page()==3){
  if(y>=142&&y<178){if(!timerRunning&&x>=16&&x<304){unsigned col=(x-16)/74;if(col<4&&(x-16)%74<66){const unsigned minutes[]={5,10,15,30};timerMinutes=minutes[col];resetTimer();pages.touched(millis());drawPage("countdown_preset");}}return;}
  if(y>=194&&y<232){if(x>=16&&x<304){unsigned col=(x-16)/98;if((x-16)%98<92){if(col==2)openSettings();else toolAction(col==0?4:5);}}return;}
 }
 pages.pinned=false;pinNoticeAt=0;if(x<160)pages.previous();else pages.next();drawPage("touch_page");
}
void deskTick(){if(pinNoticeAt&&uint32_t(millis()-pinNoticeAt)>=1200){pinNoticeAt=0;if(running&&!settingsShowing&&!forecastShowing&&!webConfig.isAP())drawPage("pin_notice_done");}bool shown=running&&!webConfig.isAP()&&!settingsShowing&&!forecastShowing&&pages.page()==0&&!gesture.held();if(homeMarquee.tick(shown))drawTicker();uint32_t old=uiRevision;refreshDeskConfig();if(biblePending&&running&&!settingsShowing&&!forecastShowing&&pages.page()==1&&!weatherService.busy()&&ESP.getFreeHeap()>=70000)drawPage("content_refresh");unsigned command=desk::command().exchange(0);if(command)toolAction(command);bool night=nightPeriod();if(old!=uiRevision||(!webConfig.isAP()&&night!=isNight)){palette();if(running)drawPage("settings_changed");}if(timerRunning&&!remaining()){timerRunning=false;timerRemainingMs=0;timerComplete=true;Serial.println("TIMER complete=true");if(pages.page()==3&&!settingsShowing&&!forecastShowing)drawPage("timer_completed");}if(!pinNoticeAt&&millis()-uiTickAt>=1000){uiTickAt=millis();if(running&&!webConfig.isAP()&&!settingsShowing&&!forecastShowing){uint32_t value=pages.page()==3?(remaining()+999)/1000:uint32_t(time(nullptr)/(pages.page()==0?1:60));value^=uint32_t(pages.page())<<28;if(value!=lastDynamicValue){lastDynamicValue=value;if(pages.page()==0)drawHomeClock(false);else if(pages.page()==3)drawCountdownValue();else if(pages.page()==2)drawPage("content_refresh");}}}}
