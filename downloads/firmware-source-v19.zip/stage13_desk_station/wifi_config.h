#pragma once
#include <stddef.h>
#include <string.h>
namespace wifi_config {
constexpr size_t MAX_BYTES=512;
struct Credentials { char ssid[33]={}; char password[65]={}; };
enum class Result { Okay, TooLarge, Invalid, Duplicate, Missing, Placeholder };
// No logging. Preserve spaces inside values; reject controls/NUL and unknown keys.
inline Result parse(const char *data, size_t bytes, Credentials &output) {
  if(bytes>MAX_BYTES) return Result::TooLarge;
  Credentials candidate; bool ssidSeen=false,passwordSeen=false;
  size_t pos=0;
  if(bytes>=3 && (unsigned char)data[0]==0xef && (unsigned char)data[1]==0xbb && (unsigned char)data[2]==0xbf) pos=3;
  while(pos<bytes) {
    size_t start=pos; while(pos<bytes && data[pos]!='\n') ++pos;
    size_t length=pos-start; if(pos<bytes) ++pos;
    if(length && data[start+length-1]=='\r') --length;
    for(size_t i=0;i<length;++i) if((unsigned char)data[start+i]<32 || data[start+i]==127) return Result::Invalid;
    if(!length || data[start]=='#') continue;
    const char *line=data+start,*value=nullptr; size_t valueBytes=0; char *target=nullptr; size_t limit=0;
    if(length>=5 && memcmp(line,"SSID=",5)==0) {
      if(ssidSeen) return Result::Duplicate;
      ssidSeen=true; value=line+5;valueBytes=length-5;target=candidate.ssid;limit=32;
    } else if(length>=9 && memcmp(line,"PASSWORD=",9)==0) {
      if(passwordSeen) return Result::Duplicate;
      passwordSeen=true;value=line+9;valueBytes=length-9;target=candidate.password;limit=64;
    } else return Result::Invalid;
    if(valueBytes>limit) return Result::Invalid;
    memcpy(target,value,valueBytes);target[valueBytes]=0;
  }
  if(!ssidSeen || !passwordSeen || !candidate.ssid[0]) return Result::Missing;
  if(strcmp(candidate.ssid,"YOUR_WIFI_NAME")==0 || strcmp(candidate.password,"YOUR_WIFI_PASSWORD")==0) return Result::Placeholder;
  size_t pw=strlen(candidate.password);
  if(pw && pw<8) return Result::Invalid;
  if(pw==64) for(size_t i=0;i<pw;++i) {
    char c=candidate.password[i];
    if(!((c>='0' && c<='9') || (c>='a' && c<='f') || (c>='A' && c<='F'))) return Result::Invalid;
  }
  output=candidate;return Result::Okay;
}
}
