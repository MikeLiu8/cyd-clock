#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "daily_reader.h"
namespace fontmeta {
struct Metadata {uint32_t bytes16=0,bytes24=0,crc16=0,crc24=0;};
inline bool number(const char *s,uint32_t limit,uint32_t &out) {
  if(!*s) return false;
  uint32_t n=0;
  while(*s) {
    if(*s<'0'||*s>'9') return false;
    uint32_t digit=uint32_t(*s++-'0');
    if(digit>limit || n>(limit-digit)/10) return false;
    n=n*10+digit;
  }
  out=n;return true;
}
inline bool parse(char *line,const daily::Reference &expected,uint32_t limit16,uint32_t limit24,Metadata &out) {
  char *parts[7]={line};unsigned commas=0;
  for(char *p=line;*p;++p) if(*p==',') {if(commas>=6) return false;*p=0;parts[++commas]=p+1;}
  if(commas!=6 || strcmp(parts[0],expected.book)!=0) return false;
  uint32_t ch=0,verse=0;Metadata candidate;
  if(!number(parts[1],999,ch)||!number(parts[2],999,verse)||ch!=expected.chapter||verse!=expected.verse) return false;
  if(!number(parts[3],limit16,candidate.bytes16)||candidate.bytes16<24 ||
     !number(parts[4],limit24,candidate.bytes24)||candidate.bytes24<24 ||
     !number(parts[5],UINT32_MAX,candidate.crc16)||!number(parts[6],UINT32_MAX,candidate.crc24)) return false;
  out=candidate;return true;
}
// Validate a bounded VLW cache before the display library may read its offsets.
inline int32_t bigEndian(const uint8_t *p) {
  return static_cast<int32_t>((uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3]);
}
inline bool validFont(const uint8_t *p,size_t bytes,uint8_t size) {
  if(!p || bytes<24) return false;
  int32_t h[6];for(unsigned i=0;i<6;++i) h[i]=bigEndian(p+4*i);
  if(h[0]<=0 || h[0]>512 || h[1]!=11 || h[2]!=size || h[4]<=0 || h[4]>64 || h[5]<0 || h[5]>32) return false;
  size_t total=24+28*size_t(h[0]);if(total>bytes) return false;
  for(int32_t i=0;i<h[0];++i) {
    int32_t g[7];for(unsigned k=0;k<7;++k) g[k]=bigEndian(p+24+28*size_t(i)+4*k);
    if(g[0]<33 || g[0]>65535 || g[1]<=0 || g[1]>64 || g[2]<=0 || g[2]>64 || g[3]<=0 || g[3]>64 || g[4]<-64 || g[4]>64 || g[5]<-64 || g[5]>64) return false;
    size_t bitmap=size_t(g[1])*size_t(g[2]);if(bitmap>bytes-total) return false;
    total+=bitmap;
  }
  return total==bytes;
}
// Standard IEEE CRC32, compatible with Python zlib.crc32. Streaming, no extra file buffer.
inline uint32_t crcByte(uint32_t crc,uint8_t byte) {
  crc^=byte;
  for(unsigned bit=0;bit<8;++bit) crc=(crc>>1)^((crc&1)?0xedb88320u:0u);
  return crc;
}
}
