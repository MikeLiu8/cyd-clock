#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include <atomic>
#include <new>
#include <time.h>
#include <cJSON.h>
#include <mbedtls/base64.h>
#include <nvs.h>
#include "settings_codec.h"
namespace desk {
constexpr size_t LINE_BYTES=288*18/8;
struct Bus {char route[9],stop[17],direction;uint8_t service;uint16_t seq;char stopName[97],destination[97];uint8_t stopImage[LINE_BYTES],destinationImage[LINE_BYTES];};
struct Reminder {char date[11],time[6],text[65];uint8_t image[LINE_BYTES];};
// Keep the exact RAM records and v07 key. v12 stores a bounded lossless wrapper
// in desk_v2 after Save; old uncompressed desk_v2 records remain readable.
struct LegacyConfig {uint32_t version;Bus bus;Reminder reminders[4];uint8_t count,focusMinutes,restMinutes;uint16_t countMinutes,nightStart,nightEnd;uint8_t dayBrightness,nightBrightness,interval;bool nightEnabled,colour,automatic;char qrUrl[101];uint32_t crc;};
struct Config {uint32_t version;LegacyConfig settings;Bus additional[2];uint32_t crc;};
// Display snapshot only: durable Config/DKZ1 layout stays byte-for-byte compatible.
struct UiPreferences {Bus bus;uint16_t countMinutes,nightStart,nightEnd;uint8_t dayBrightness,nightBrightness,interval;bool nightEnabled,colour,automatic;};
struct UiConfig {UiPreferences settings;Bus additional[2];};
static_assert(sizeof(UiConfig)<=sizeof(Config)-2800,"UI snapshot must retain the RAM saving");
struct BusKey {char route[9],stop[17],direction;uint8_t service;uint16_t seq;};
inline Bus &slot(Config &v,unsigned i){return i?v.additional[i-1]:v.settings.bus;}
inline const Bus &slot(const Config &v,unsigned i){return i?v.additional[i-1]:v.settings.bus;}
inline const Bus &slot(const UiConfig &v,unsigned i){return i?v.additional[i-1]:v.settings.bus;}
inline bool styledImage(const uint8_t *p,bool destination){return p[0]=='C'&&p[1]=='Y'&&p[2]=='D'&&p[3]==13&&p[4]==128&&p[5]==(destination?24:18)&&p[6]==(destination?18:14)&&p[7]==(destination?6:4);}
inline bool styledLabels(const Config &v){for(unsigned i=0;i<3;++i){const auto &b=slot(v,i);if(b.route[0]&&(!styledImage(b.stopImage,false)||!styledImage(b.destinationImage,true)))return false;}return true;}
inline SemaphoreHandle_t &mutex(){static SemaphoreHandle_t v=nullptr;return v;}
inline SemaphoreHandle_t &networkGate(){static SemaphoreHandle_t v=nullptr;return v;}
struct Gate {bool held=false;Gate(){held=networkGate() && xSemaphoreTake(networkGate(),0)==pdTRUE;}~Gate(){if(held)xSemaphoreGive(networkGate());}};
inline std::atomic<unsigned> &command(){static std::atomic<unsigned> c{0};return c;}
inline Config &data(){static Config v={};return v;}
inline std::atomic<uint32_t> &revision(){static std::atomic<uint32_t> r{1};return r;}
template<class T> uint32_t checksum(const T &v){const uint8_t *p=reinterpret_cast<const uint8_t*>(&v);uint32_t c=2166136261u;for(size_t i=0;i<offsetof(T,crc);++i)c=(c^p[i])*16777619u;return c;}
inline bool copy(Config &out,uint32_t *snapshotRevision=nullptr){if(!mutex() || xSemaphoreTake(mutex(),pdMS_TO_TICKS(20))!=pdTRUE)return false;out=data();if(snapshotRevision)*snapshotRevision=revision().load();xSemaphoreGive(mutex());return true;}
inline bool copy(UiConfig &out,uint32_t *snapshotRevision=nullptr){
 if(!mutex()||xSemaphoreTake(mutex(),pdMS_TO_TICKS(20))!=pdTRUE)return false;
 const auto &v=data();const auto &p=v.settings;auto &u=out.settings;
 u.bus=p.bus;out.additional[0]=v.additional[0];out.additional[1]=v.additional[1];
 u.countMinutes=p.countMinutes;u.nightStart=p.nightStart;u.nightEnd=p.nightEnd;
 u.dayBrightness=p.dayBrightness;u.nightBrightness=p.nightBrightness;u.interval=p.interval;
 u.nightEnabled=p.nightEnabled;u.colour=p.colour;u.automatic=p.automatic;
 if(snapshotRevision)*snapshotRevision=revision().load();xSemaphoreGive(mutex());return true;
}
inline BusKey bus(unsigned index,uint32_t *snapshotRevision=nullptr){BusKey out={};if(index<3&&mutex() && xSemaphoreTake(mutex(),pdMS_TO_TICKS(20))==pdTRUE){const auto &b=slot(data(),index);memcpy(out.route,b.route,sizeof(out.route));memcpy(out.stop,b.stop,sizeof(out.stop));out.direction=b.direction;out.service=b.service;out.seq=b.seq;if(snapshotRevision)*snapshotRevision=revision().load();xSemaphoreGive(mutex());}return out;}
inline bool ascii(const char *s,size_t max,bool hex=false){size_t n=strlen(s);if(!n||n>max)return false;for(size_t i=0;i<n;++i)if(hex?!isxdigit(static_cast<unsigned char>(s[i])):!(s[i]>='A'&&s[i]<='Z')&&!(s[i]>='0'&&s[i]<='9'))return false;return true;}
inline bool validBus(const Bus &b){return memchr(b.route,0,sizeof(b.route))&&memchr(b.stop,0,sizeof(b.stop))&&memchr(b.stopName,0,sizeof(b.stopName))&&memchr(b.destination,0,sizeof(b.destination))&&ascii(b.route,8)&&ascii(b.stop,16,true)&&strlen(b.stop)==16&&(b.direction=='O'||b.direction=='I')&&b.service>=1&&b.service<=99&&b.seq>=1&&b.seq<=300;}
inline bool valid(const LegacyConfig &v){return v.version==1 && v.crc==checksum(v) && v.count<=4 && v.focusMinutes>=1&&v.focusMinutes<=120&&v.restMinutes>=1&&v.restMinutes<=60&&v.countMinutes>=1&&v.countMinutes<=240&&v.nightStart<1440&&v.nightEnd<1440&&v.dayBrightness>=20&&v.nightBrightness>=5&&v.interval>=5&&v.interval<=60 && memchr(v.qrUrl,0,sizeof(v.qrUrl))&&validBus(v.bus);}
inline bool valid(const Config &v){return v.version==2&&v.crc==checksum(v)&&valid(v.settings)&&(!v.additional[0].route[0]||validBus(v.additional[0]))&&(!v.additional[1].route[0]||validBus(v.additional[1]));}
inline void defaults(Config &v){memset(&v,0,sizeof(v));v.version=2;auto &p=v.settings;p.version=1;strcpy(p.bus.route,"E41");strcpy(p.bus.stop,"9DD63D93684C27D6");p.bus.direction='O';p.bus.service=1;p.bus.seq=1;strcpy(p.bus.stopName,"大埔頭總站 (TP975)");strcpy(p.bus.destination,"航天城");p.focusMinutes=25;p.restMinutes=5;p.countMinutes=10;p.nightStart=1320;p.nightEnd=420;p.dayBrightness=255;p.nightBrightness=60;p.interval=12;p.colour=true;p.automatic=true;p.crc=checksum(p);v.crc=checksum(v);}
inline bool loadStored(Preferences &p,Config &v){
 size_t bytes=p.getBytesLength("desk_v2");
 if(bytes==sizeof(v))return p.getBytes("desk_v2",&v,sizeof(v))==sizeof(v)&&valid(v);
 if(bytes<sizeof(settings_codec::Header)||bytes>settings_codec::LIMIT)return false;
 auto stored=new(std::nothrow) uint8_t[bytes];if(!stored)return false;uint32_t crc=0;
 bool ok=p.getBytes("desk_v2",stored,bytes)==bytes&&settings_codec::restore(stored,bytes,&v,sizeof(v),crc)&&crc==v.crc&&valid(v);
 delete[] stored;return ok;
}
inline void begin(){mutex()=xSemaphoreCreateMutex();networkGate()=xSemaphoreCreateMutex();defaults(data());Preferences p;if(p.begin("cydprefs",true)){auto v=new(std::nothrow) Config;if(v){if(loadStored(p,*v))data()=*v;else if(p.getBytesLength("desk_v1")==sizeof(LegacyConfig)&&p.getBytes("desk_v1",&v->settings,sizeof(LegacyConfig))==sizeof(LegacyConfig)&&valid(v->settings)){data().settings=v->settings;data().crc=checksum(data());}delete v;}p.end();}}
struct SaveFailure {const char *stage="none";esp_err_t code=ESP_OK;};
inline void reportLabels(){
 bool present[3],stops[3],destinations[3];if(!mutex()||xSemaphoreTake(mutex(),pdMS_TO_TICKS(20))!=pdTRUE)return;
 for(unsigned i=0;i<3;++i){const auto &b=slot(data(),i);present[i]=b.route[0];stops[i]=styledImage(b.stopImage,false);destinations[i]=styledImage(b.destinationImage,true);}xSemaphoreGive(mutex());
 for(unsigned i=0;i<3;++i)Serial.printf("DESK_LABEL slot=%u present=%s stop_style=%s destination_style=%s\n",i+1,present[i]?"true":"false",stops[i]?"14_regular":"legacy",destinations[i]?"18_semibold":"legacy");
}
inline void reportStorage(size_t stored=0,const char *stage="query",esp_err_t code=ESP_OK){
 nvs_stats_t stats={};esp_err_t result=nvs_get_stats(nullptr,&stats);
 Preferences p;size_t old=0,current=0;if(p.begin("cydprefs",true)){old=p.getBytesLength("desk_v1");current=p.getBytesLength("desk_v2");p.end();}
 Serial.printf("DESK_STORAGE stage=%s code=%s raw=%u stored=%u legacy=%u current=%u used=%u free=%u available=%u stats=%s\n",stage,esp_err_to_name(code),unsigned(sizeof(Config)),unsigned(stored),unsigned(old),unsigned(current),unsigned(stats.used_entries),unsigned(stats.free_entries),unsigned(stats.available_entries),esp_err_to_name(result));
 reportLabels();
}
inline bool save(Config &v,SaveFailure *failure=nullptr){
 v.version=2;v.settings.crc=checksum(v.settings);v.crc=checksum(v);
 if(!valid(v)){if(failure)*failure={"validate",ESP_ERR_INVALID_ARG};return false;}
 auto stored=new(std::nothrow) uint8_t[settings_codec::LIMIT];
 if(!stored){if(failure)*failure={"allocate",ESP_ERR_NO_MEM};return false;}
 size_t bytes=settings_codec::pack(&v,sizeof(v),v.crc,stored,settings_codec::LIMIT);
 const char *stage="encode";esp_err_t err=bytes?ESP_OK:ESP_ERR_INVALID_SIZE;
 if(err==ESP_OK){
  nvs_handle_t handle;stage="open";err=nvs_open("cydprefs",NVS_READWRITE,&handle);
  if(err==ESP_OK){stage="write";err=nvs_set_blob(handle,"desk_v2",stored,bytes);if(err==ESP_OK){stage="commit";err=nvs_commit(handle);}nvs_close(handle);}
  if(err==ESP_OK){stage="read_open";err=nvs_open("cydprefs",NVS_READONLY,&handle);
   if(err==ESP_OK){size_t readBytes=settings_codec::LIMIT;stage="read";err=nvs_get_blob(handle,"desk_v2",stored,&readBytes);nvs_close(handle);
    if(err==ESP_OK){uint32_t crc=0;stage="verify";if(readBytes!=bytes||!settings_codec::restore(stored,readBytes,&v,sizeof(v),crc,true)||crc!=v.crc)err=ESP_ERR_INVALID_CRC;}
   }
  }
 }
 delete[] stored;
 if(err==ESP_OK){stage="apply";if(mutex()&&xSemaphoreTake(mutex(),pdMS_TO_TICKS(100))==pdTRUE){data()=v;revision().fetch_add(1);xSemaphoreGive(mutex());}else err=ESP_ERR_TIMEOUT;}
 if(failure)*failure={err==ESP_OK?"saved":stage,err};reportStorage(bytes,err==ESP_OK?"saved":stage,err);return err==ESP_OK;
}
inline cJSON *get(cJSON *j,const char *key){return cJSON_GetObjectItemCaseSensitive(j,key);}
inline bool str(cJSON *j,const char *key,char *out,size_t capacity,bool empty=false){auto v=get(j,key);if(!cJSON_IsString(v))return false;size_t n=strlen(v->valuestring);if(n>=capacity||(!empty&&!n))return false;for(size_t i=0;i<n;++i)if(static_cast<unsigned char>(v->valuestring[i])<32)return false;memcpy(out,v->valuestring,n+1);return true;}
inline bool integer(cJSON *j,const char *key,unsigned lo,unsigned hi,unsigned &out){auto v=get(j,key);if(!cJSON_IsNumber(v)||!isfinite(v->valuedouble)||v->valuedouble<lo||v->valuedouble>hi||v->valuedouble!=unsigned(v->valuedouble))return false;out=unsigned(v->valuedouble);return true;}
inline bool image(cJSON *j,const char *key,uint8_t *out){auto v=get(j,key);if(!cJSON_IsString(v)||strlen(v->valuestring)!=LINE_BYTES*4/3)return false;size_t n=0;return mbedtls_base64_decode(out,LINE_BYTES,&n,reinterpret_cast<const unsigned char*>(v->valuestring),strlen(v->valuestring))==0&&n==LINE_BYTES;}
inline bool parsePrimary(cJSON *root,LegacyConfig &v){auto b=get(root,"bus"),t=get(root,"tools"),d=get(root,"display");char dir[2];unsigned n;if(!cJSON_IsObject(b)||!cJSON_IsObject(t)||!cJSON_IsObject(d))return false;
 if(!str(b,"route",v.bus.route,sizeof(v.bus.route))||!str(b,"stop",v.bus.stop,sizeof(v.bus.stop))||!str(b,"direction",dir,sizeof(dir))||!str(b,"stopName",v.bus.stopName,sizeof(v.bus.stopName))||!str(b,"destination",v.bus.destination,sizeof(v.bus.destination))||!integer(b,"service",1,99,n))return false;v.bus.service=n;v.bus.direction=dir[0];if(!integer(b,"seq",1,300,n))return false;v.bus.seq=n;
 if(!image(b,"stopImage",v.bus.stopImage)||!image(b,"destinationImage",v.bus.destinationImage))return false;
 // Legacy reminder slots remain in Config/NVS for rollback; no schedule API.
 if(!integer(t,"focus",1,120,n))return false;v.focusMinutes=n;if(!integer(t,"rest",1,60,n))return false;v.restMinutes=n;if(!integer(t,"count",1,240,n))return false;v.countMinutes=n;if(!str(t,"qrUrl",v.qrUrl,sizeof(v.qrUrl),true))return false;if(v.qrUrl[0]&&(strncmp(v.qrUrl,"https://",8)!=0&&strncmp(v.qrUrl,"http://",7)!=0))return false;if(v.qrUrl[0]&&strlen(v.qrUrl)<9)return false;for(const char *p=v.qrUrl;*p;++p)if(static_cast<unsigned char>(*p)>126||*p=='@')return false;
 if(!integer(d,"nightStart",0,1439,n))return false;v.nightStart=n;if(!integer(d,"nightEnd",0,1439,n))return false;v.nightEnd=n;if(!integer(d,"dayBrightness",20,255,n))return false;v.dayBrightness=n;if(!integer(d,"nightBrightness",5,255,n))return false;v.nightBrightness=n;if(!integer(d,"interval",5,60,n))return false;v.interval=n;
 if(!cJSON_IsBool(get(d,"nightEnabled"))||!cJSON_IsBool(get(d,"colour"))||!cJSON_IsBool(get(d,"automatic")))return false;v.nightEnabled=cJSON_IsTrue(get(d,"nightEnabled"));v.colour=cJSON_IsTrue(get(d,"colour"));v.automatic=cJSON_IsTrue(get(d,"automatic"));v.crc=checksum(v);return valid(v);
}
inline bool parseBus(cJSON *b,Bus &v){char dir[2];unsigned n;memset(&v,0,sizeof(v));if(!cJSON_IsObject(b)||!str(b,"route",v.route,sizeof(v.route))||!str(b,"stop",v.stop,sizeof(v.stop))||!str(b,"direction",dir,sizeof(dir))||!str(b,"stopName",v.stopName,sizeof(v.stopName))||!str(b,"destination",v.destination,sizeof(v.destination))||!integer(b,"service",1,99,n))return false;v.service=n;v.direction=dir[0];if(!integer(b,"seq",1,300,n))return false;v.seq=n;return image(b,"stopImage",v.stopImage)&&image(b,"destinationImage",v.destinationImage)&&validBus(v);}
inline bool parse(cJSON *root,Config &v){if(!parsePrimary(root,v.settings))return false;auto list=get(root,"extraBuses");if(list){if(!cJSON_IsArray(list)||cJSON_GetArraySize(list)!=2)return false;for(unsigned i=0;i<2;++i){auto b=cJSON_GetArrayItem(list,i);if(cJSON_IsNull(b))memset(&v.additional[i],0,sizeof(Bus));else if(!parseBus(b,v.additional[i]))return false;}}v.crc=checksum(v);return valid(v);}
inline cJSON *busJson(const Bus &v){auto b=cJSON_CreateObject();if(!b)return nullptr;char bound[2]={v.direction,0};cJSON_AddStringToObject(b,"route",v.route);cJSON_AddStringToObject(b,"stop",v.stop);cJSON_AddStringToObject(b,"direction",bound);cJSON_AddNumberToObject(b,"service",v.service);cJSON_AddNumberToObject(b,"seq",v.seq);cJSON_AddStringToObject(b,"stopName",v.stopName);cJSON_AddStringToObject(b,"destination",v.destination);return b;}
inline cJSON *json(const Config &config){const auto &v=config.settings;auto root=cJSON_CreateObject(),t=cJSON_AddObjectToObject(root,"tools"),d=cJSON_AddObjectToObject(root,"display"),list=cJSON_AddArrayToObject(root,"extraBuses"),b=busJson(v.bus);if(!root||!b||!t||!d||!list){cJSON_Delete(b);cJSON_Delete(root);return nullptr;}cJSON_AddItemToObject(root,"bus",b);for(unsigned i=0;i<2;++i){auto extra=config.additional[i].route[0]?busJson(config.additional[i]):cJSON_CreateNull();if(!extra){cJSON_Delete(root);return nullptr;}cJSON_AddItemToArray(list,extra);}cJSON_AddNumberToObject(t,"focus",v.focusMinutes);cJSON_AddNumberToObject(t,"rest",v.restMinutes);cJSON_AddNumberToObject(t,"count",v.countMinutes);cJSON_AddStringToObject(t,"qrUrl",v.qrUrl);cJSON_AddNumberToObject(d,"nightStart",v.nightStart);cJSON_AddNumberToObject(d,"nightEnd",v.nightEnd);cJSON_AddNumberToObject(d,"dayBrightness",v.dayBrightness);cJSON_AddNumberToObject(d,"nightBrightness",v.nightBrightness);cJSON_AddNumberToObject(d,"interval",v.interval);cJSON_AddBoolToObject(d,"nightEnabled",v.nightEnabled);cJSON_AddBoolToObject(d,"colour",v.colour);cJSON_AddBoolToObject(d,"automatic",v.automatic);return root;}
}
