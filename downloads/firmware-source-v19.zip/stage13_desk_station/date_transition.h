#pragma once
#include "daily_reader.h"
// Failed/missing day loads still count as one attempt: no SD retry every frame.
// A later explicit retry can request that date again. Held touch defers the swap.
struct DateTransition {
  daily::Date last;
  bool attempted=false;
  bool needs(daily::Date date) const {return daily::valid(date) && (!attempted || date.year!=last.year || date.month!=last.month || date.day!=last.day);}
  void applied(daily::Date date) {last=date;attempted=true;}
};
