const D=id=>document.getElementById(id),dm=D('desk-message'),BK='https://data.etabus.gov.hk/v1/transport/kmb/';let bag=null,routes=null,names=null,choices=[],generation=0,etaVersion=0;
const pinValue=()=>{const p=D('pin').value;if(!/^[0-9]{6}$/.test(p))throw Error('請先輸入畫面上的六位 PIN。');return p};
const bytes=s=>new TextEncoder().encode(s).length;
function busMessage(text){dm.textContent=text;for(const id of ['bus-message','bus-save-message','desk-save-message'])D(id).textContent=text;}
function busError(e){return e.name==='TimeoutError'||e.name==='AbortError'?'查詢逾時，請稍後重試。':e instanceof TypeError?'未能連接資料服務，請確認手機／電腦的網絡後重試。':e.message;}
async function official(path){const r=await fetch(BK+path,{signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('官方 API '+r.status);const j=await r.json();if(!j.data)throw Error('資料格式不符');return j;}
const selectedSlot=()=>Number(D('bus-slot').value);
const favoriteAt=i=>i?bag.extraBuses[i-1]:bag.bus;
function setFavorite(i,b){if(i)bag.extraBuses[i-1]=b;else bag.bus=b;}
function info(){if(!bag)return;D('bus-choice').replaceChildren();for(let i=0;i<3;i++){const b=favoriteAt(i),line=document.createElement('p');line.textContent='收藏 '+(i+1)+'：'+(b?b.route+' → '+b.destination+'；'+b.stopName:'尚未收藏');D('bus-choice').append(line)}D('bus-clear').disabled=selectedSlot()===0||!favoriteAt(selectedSlot());}
function selectSlot(){++generation;++etaVersion;choices=[];D('direction').replaceChildren(new Option('先搜尋路線',''));D('stop').replaceChildren(new Option('先選方向',''));D('direction').disabled=D('stop').disabled=D('bus-select').disabled=true;D('route').value=favoriteAt(selectedSlot())?.route||'';info();showEta();}
D('bus-slot').onchange=()=>{if(bag)selectSlot();else ++generation};
D('bus-clear').onclick=()=>{if(!bag||selectedSlot()===0)return;setFavorite(selectedSlot(),null);selectSlot();busMessage('已清除這個收藏，尚未儲存到 CYD。');};
function minute(t){const [h,m]=t.split(':').map(Number);if(!Number.isInteger(h)||!Number.isInteger(m)||h<0||h>23||m<0||m>59)throw Error('夜間時間不正確');return h*60+m;}
function timeValue(n){return String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0');}
async function loadDesk(keepSearch=false){D('desk-load').disabled=true;if(!keepSearch)D('route-search').disabled=true;try{const r=await fetch('/desk-settings',{headers:{'X-Setup-Pin':pinValue()},signal:AbortSignal.timeout(6000)});if(!r.ok)throw Error(await r.text());bag=await r.json();bag.extraBuses??=[null,null];D('count').value=bag.tools.count;for(const k of ['colour','automatic'])D(k).checked=bag.display[k];D('night-enabled').checked=bag.display.nightEnabled;D('interval').value=bag.display.interval;D('night-start').value=timeValue(bag.display.nightStart);D('night-end').value=timeValue(bag.display.nightEnd);D('day-brightness').value=bag.display.dayBrightness;D('night-brightness').value=bag.display.nightBrightness;if(keepSearch)info();else selectSlot();busMessage('已讀取板上設定。修改後請按儲存。');}finally{D('desk-load').disabled=false;if(!keepSearch)D('route-search').disabled=false;}}
D('desk-load').onclick=async()=>{try{await loadDesk()}catch(e){busMessage(busError(e))}};
D('route-search').onclick=async()=>{const id=++generation,route=D('route').value.trim().toUpperCase();if(!/^[A-Z0-9]{1,8}$/.test(route)){busMessage('路線號碼不正確');return}D('route-search').disabled=true;D('direction').disabled=true;D('stop').disabled=true;D('bus-select').disabled=true;try{if(!bag){busMessage('正在讀取 CYD 設定…');await loadDesk(true);}if(id!==generation)return;D('route').value=route;busMessage('正在搜尋 '+route+' 的官方路線…');if(!routes)routes=(await official('route/')).data;if(id!==generation)return;choices=routes.filter(r=>r.route===route);if(!choices.length)throw Error('找不到此九巴／龍運路線');D('direction').replaceChildren();choices.forEach((r,i)=>D('direction').add(new Option(r.orig_tc+' → '+r.dest_tc+'（類型 '+r.service_type+'）',i)));D('direction').disabled=false;await stops(id)}catch(e){if(id===generation)busMessage(busError(e))}finally{D('route-search').disabled=false}};
async function stops(id){const r=choices[Number(D('direction').value)];D('stop').disabled=true;D('bus-select').disabled=true;busMessage('正在讀取上車站…');try{const j=await official('route-stop/'+r.route+'/'+(r.bound==='O'?'outbound':'inbound')+'/'+r.service_type);if(!names)names=new Map((await official('stop')).data.map(x=>[x.stop,x.name_tc]));if(id!==generation)return;D('stop').replaceChildren();j.data.sort((a,b)=>Number(a.seq)-Number(b.seq)).forEach(x=>D('stop').add(new Option(x.seq+' · '+(names.get(x.stop)||x.stop),JSON.stringify(x))));D('stop').disabled=false;D('bus-select').disabled=!D('stop').options.length;busMessage('選方向及上車站，再按「選用此站」和儲存。')}catch(e){if(id===generation)busMessage(busError(e))}}
D('direction').onchange=()=>stops(++generation);
D('bus-select').onclick=()=>{const r=choices[Number(D('direction').value)],s=JSON.parse(D('stop').value);setFavorite(selectedSlot(),{route:r.route,stop:s.stop,direction:r.bound,service:Number(r.service_type),seq:Number(s.seq),stopName:names.get(s.stop)||s.stop,destination:r.dest_tc});info();busMessage('已選用此站，尚未儲存到 CYD。');showEta()};
async function showEta(){if(!bag)return;const id=++etaVersion,chosen=favoriteAt(selectedSlot());if(!chosen){D('eta-preview').textContent='此收藏尚未設定。';return}const b={...chosen};try{const j=await official('eta/'+b.stop+'/'+b.route+'/'+b.service);if(id!==etaVersion)return;const rows=j.data.filter(x=>x.route===b.route&&x.dir===b.direction&&Number(x.service_type)===b.service&&Number(x.seq)===b.seq).sort((a,b)=>a.eta_seq-b.eta_seq);D('eta-preview').textContent='官方到站：'+(rows.map(x=>x.eta?new Date(x.eta).toLocaleTimeString('zh-HK',{timeZone:'Asia/Hong_Kong',hour:'2-digit',minute:'2-digit'})+(x.rmk_tc?' '+x.rmk_tc:''):x.rmk_tc||'暫未提供時間').join(' ／ ')||'暫未提供時間')}catch(e){if(id===etaVersion)D('eta-preview').textContent='到站更新失敗：'+e.message}}
// Local system fonts are already used by the page; do not wait on FontFaceSet.ready.
async function raster(text,size,weight){return btoa(String.fromCharCode(...busLabelBits(text,size,weight)))}
let savingDesk=false;
function saveMessage(text){busMessage(text);}
async function saveDesk(){
 if(savingDesk)return;
 if(!bag){saveMessage('請先搜尋路線或讀取目前設定。');return;}
 savingDesk=true;const buttons=[D('bus-save'),D('desk-save')],labels=buttons.map(b=>b.textContent);
 buttons.forEach(b=>{b.disabled=true;b.textContent='儲存中…';});saveMessage('正在準備儲存…');
 try{
  const pin=pinValue(),payload=JSON.parse(JSON.stringify(bag));
  payload.tools.count=Number(D('count').value);
  payload.display={colour:D('colour').checked,automatic:D('automatic').checked,interval:Number(D('interval').value),nightEnabled:D('night-enabled').checked,nightStart:minute(D('night-start').value),nightEnd:minute(D('night-end').value),dayBrightness:Number(D('day-brightness').value),nightBrightness:Number(D('night-brightness').value)};
  payload.pin=pin;
  for(const b of [payload.bus,...payload.extraBuses]){if(!b)continue;b.stopImage=await raster(b.stopName.replace(/ \([A-Z0-9]+\)$/,''),14,400);b.destinationImage=await raster(b.destination,18,600);}
  saveMessage('正在傳送設定及核對…');
  const response=await fetch('/desk-save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(8000)}),text=await response.text();
  saveMessage(response.ok?(text||'CYD 未提供儲存確認，請讀取目前設定核對。'):'儲存失敗（HTTP '+response.status+'）：'+text);
 }catch(e){saveMessage('未能確認儲存：'+(e.name==='TimeoutError'||e.name==='AbortError'?'傳送逾時，請讀取目前設定核對。':e.message)+' 待儲存內容仍保留在此頁。');}
 finally{buttons.forEach((b,i)=>{b.disabled=false;b.textContent=labels[i];});savingDesk=false;}
}
D('bus-save').onclick=D('desk-save').onclick=saveDesk;
document.querySelectorAll('[data-command]').forEach(b=>b.onclick=async()=>{try{const r=await fetch('/desk-command',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pin:pinValue(),action:b.dataset.command}),signal:AbortSignal.timeout(6000)});dm.textContent=await r.text()}catch(e){dm.textContent=e.message}});
