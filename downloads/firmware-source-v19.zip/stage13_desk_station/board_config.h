#pragma once
#include <stdint.h>
#include <stddef.h>
namespace board_config {
constexpr int SD_MOSI=23, SD_MISO=19, SD_SCLK=18, SD_CS=5;
constexpr int LCD_MOSI=13, LCD_MISO=12, LCD_SCLK=14, LCD_CS=15, LCD_DC=2;
constexpr int BACKLIGHT=21;
constexpr int TOUCH_MOSI=32, TOUCH_MISO=39, TOUCH_SCLK=25, TOUCH_CS=33, TOUCH_IRQ=36;
constexpr uint8_t RAW_TOUCH_ROTATION=1;
// Same-board R1 coefficients: independent five-point PASS, maximum 2.8px.
// evidence/hardware/display_touch_v02_touch_r1_result.json (2026-10-08).
constexpr float TOUCH_X[3]={0.0885181725f,-0.000477550435f,-15.637537f};
constexpr float TOUCH_Y[3]={0.000463229459f,0.0665607825f,-22.0830536f};
constexpr uint32_t TOUCH_POLL_MS=20, FONT_CACHE_LIMIT=98304;
constexpr uint32_t SERIAL_BAUD=115200, SD_SPI_HZ=1000000;
constexpr uint8_t ROTATION=1;
constexpr size_t VERSE_BUFFER_BYTES=2048, MAX_CHAPTER_BYTES=262144;
constexpr const char *DAILY_CSV_PATH="/daily_verses.csv", *DATE_PATH="/date.txt";
constexpr size_t MAX_CSV_BYTES=65536;
constexpr const char *WIFI_PATH="/wifi.cfg", *TIMEZONE="HKT-8", *NTP_SERVER="stdtime.gov.hk";
constexpr uint32_t CONNECT_TIMEOUT_MS=20000, SYNC_TIMEOUT_MS=20000, RETRY_MS=60000;
constexpr unsigned MAX_ATTEMPTS=3;
constexpr const char *FIRMWARE_VERSION="stage13-desk-v19";
}
