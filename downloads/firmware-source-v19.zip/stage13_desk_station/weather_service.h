#pragma once
#include <Arduino.h>
#include <HTTPClient.h>
#include <NetworkClientSecure.h>
#include <esp_heap_caps.h>
#include <cJSON.h>
#include <time.h>
#include <atomic>
#include "weather_preferences.h"
#include "hko_root_ca.h"
#include "network_extras.h"

class WeatherService {
 public:
 enum class Status {Waiting,Fetching,Ready,Error};
 struct Snapshot {
  Status status=Status::Waiting;int station=-1;bool valid=false;
  float temperature=0,humidity=0;int icon=0;time_t reportEpoch=0;
  char reportTime[26]={},iconTime[26]={},error[32]={};uint32_t sequence=0;
 };
 struct ForecastDay {uint32_t date=0;float low=0,high=0;int icon=0;};
 struct ForecastSnapshot {Status status=Status::Waiting;bool valid=false;ForecastDay days[2];time_t reportEpoch=0;char reportTime[26]={},error[32]={};uint32_t sequence=0;};
 static_assert(sizeof(ForecastSnapshot)<256,"Only two forecast days are retained");
 static uint32_t dateKey(time_t epoch,unsigned ahead=0) {
  tm t={};localtime_r(&epoch,&t);if(t.tm_year<124)return 0;
  t.tm_hour=12;t.tm_min=0;t.tm_sec=0;t.tm_mday+=ahead;t.tm_isdst=-1;mktime(&t);
  return uint32_t(t.tm_year+1900)*10000u+uint32_t(t.tm_mon+1)*100u+t.tm_mday;
 }
 NetworkExtras extras;
 bool begin() {if(task)return true;if(!extras.begin())return false;lock=xSemaphoreCreateMutex();if(!lock)return false;
  if(xTaskCreate(worker,"hko_weather",10240,this,1,&task)!=pdPASS){vSemaphoreDelete(lock);lock=nullptr;return false;}return true;}
 Snapshot snapshot() {Snapshot out;if(lock && xSemaphoreTake(lock,pdMS_TO_TICKS(10))==pdTRUE){out=data;xSemaphoreGive(lock);}return out;}
 ForecastSnapshot forecastSnapshot(){ForecastSnapshot out;if(lock&&xSemaphoreTake(lock,pdMS_TO_TICKS(10))==pdTRUE){out=forecastData;xSemaphoreGive(lock);}return out;}
 bool busy() const {return fetching.load();}
 void tick(bool connected,bool clockValid,bool ap,bool storageIdle) {
  allowed.store(connected && clockValid && !ap);
  int station=weather_prefs::selected().load();Snapshot s=snapshot();
  if(!busy() && station!=lastStation) {lastStation=station;attempted=false;
   s={};s.station=station;publish(s);}
  if(!task || busy() || !allowed.load() || !storageIdle)return;
  if(ESP.getFreeHeap()<85000 || heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)<24000)return;
  uint32_t today=dateKey(time(nullptr));if(today!=forecastToday){forecastToday=today;forecastAttempted=false;}
  int retry=retryJob.exchange(0);if(retry==1)attempted=false;else if(retry==2)forecastAttempted=false;else if(retry)extras.defer(retry);
  uint32_t interval=s.status==Status::Error?300000u:900000u;int job=0;
  if(!attempted || uint32_t(millis()-lastAttempt)>=interval){job=1;lastAttempt=millis();attempted=true;}
  else job=extras.due(millis(),station);
  if(!job){auto f=forecastSnapshot();uint32_t every=f.status==Status::Error?300000u:3600000u;
   if(!forecastAttempted||uint32_t(millis()-lastForecastAttempt)>=every){job=2;forecastAttempted=true;lastForecastAttempt=millis();}}
  if(job){requestedJob.store(job);requestedStation.store(station);fetching.store(true);xTaskNotifyGive(task);}

 }
 void report() {Snapshot s=snapshot();Serial.printf("WEATHER status=%u valid=%s station=%s temp=%.1f humidity=%.1f icon=%d updated=%s error=%s heap=%u min_heap=%u\n",unsigned(s.status),s.valid?"true":"false",s.station>=0?weather_prefs::STATIONS[s.station].id:"none",s.temperature,s.humidity,s.icon,s.reportTime,s.error,unsigned(ESP.getFreeHeap()),unsigned(ESP.getMinFreeHeap()));}
 void reportForecast(){auto f=forecastSnapshot();Serial.printf("FORECAST status=%u valid=%s days=%u,%u updated=%s error=%s resident=%u\n",unsigned(f.status),f.valid?"true":"false",unsigned(f.days[0].date),unsigned(f.days[1].date),f.reportTime,f.error,unsigned(sizeof(ForecastSnapshot)));}
 private:
 TaskHandle_t task=nullptr;SemaphoreHandle_t lock=nullptr;Snapshot data;ForecastSnapshot forecastData;
 std::atomic<bool> allowed{false},fetching{false};std::atomic<int> requestedStation{0},requestedJob{1},retryJob{0};
 int lastStation=-1;bool attempted=false;uint32_t lastAttempt=0;
 bool forecastAttempted=false;uint32_t forecastToday=0,lastForecastAttempt=0;
 void publish(Snapshot value) {if(lock && xSemaphoreTake(lock,pdMS_TO_TICKS(20))==pdTRUE){value.sequence=data.sequence+1;data=value;xSemaphoreGive(lock);}}
 void publishForecast(ForecastSnapshot value){if(lock&&xSemaphoreTake(lock,pdMS_TO_TICKS(20))==pdTRUE){value.sequence=forecastData.sequence+1;forecastData=value;xSemaphoreGive(lock);}}
 class BodySink:public Stream {
  public:char *buffer;size_t count=0;bool failed=false;uint32_t started=millis();
  explicit BodySink(char *p):buffer(p){}
  size_t write(uint8_t c) override{return write(&c,1);}
  size_t write(const uint8_t *p,size_t n) override {
   if(count+n>8192 || uint32_t(millis()-started)>8000){failed=true;return 0;}
   memcpy(buffer+count,p,n);count+=n;buffer[count]=0;return n;
  }
  int available() override{return 0;}int read() override{return -1;}int peek() override{return -1;}void flush() override{}
 };
 static bool timestamp(const char *text,time_t &out) {
  if(!text || strlen(text)!=25 || strcmp(text+19,"+08:00")!=0)return false;
  int y,m,d,h,min,sec;char tail;
  if(sscanf(text,"%d-%d-%dT%d:%d:%d%c",&y,&m,&d,&h,&min,&sec,&tail)!=7 || tail!='+')return false;
  if(y<2024 || y>2199 || m<1 || m>12 || d<1 || d>31 || h<0 || h>23 || min<0 || min>59 || sec<0 || sec>59)return false;
  struct tm v={};v.tm_year=y-1900;v.tm_mon=m-1;v.tm_mday=d;v.tm_hour=h;v.tm_min=min;v.tm_sec=sec;v.tm_isdst=-1;
  out=mktime(&v);return out>0 && v.tm_year==y-1900 && v.tm_mon==m-1 && v.tm_mday==d;
 }
 static bool fieldNumber(cJSON *item,double lo,double hi,float &out) {
  if(!cJSON_IsNumber(item) || !isfinite(item->valuedouble) || item->valuedouble<lo || item->valuedouble>hi)return false;
  out=item->valuedouble;return true;
 }
 static cJSON *document(char *body,size_t length) {
  if(!length || strlen(body)!=length)return nullptr;
  unsigned depth=0,containers=0,separators=0;bool quoted=false,escaped=false;
  for(size_t i=0;i<length;++i){char c=body[i];if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='"')quoted=false;continue;}if(c=='"'){quoted=true;continue;}
   if(c=='{' || c=='['){if(++depth>12 || ++containers>128)return nullptr;}
   else if(c=='}' || c==']'){if(!depth)return nullptr;--depth;}else if(c==',' && ++separators>512)return nullptr;}
  if(depth || quoted)return nullptr;
  cJSON *root=cJSON_ParseWithLengthOpts(body,length+1,nullptr,true);if(!cJSON_IsObject(root)){cJSON_Delete(root);return nullptr;}return root;
 }
 static bool parse(char *body,size_t length,int station,Snapshot &out) {
  cJSON *root=document(body,length);if(!root)return false;
  bool ok=false;auto get=[](cJSON *p,const char *key){return cJSON_GetObjectItemCaseSensitive(p,key);};
  cJSON *temp=get(root,"temperature"),*humidity=get(root,"humidity"),*times=get(root,"updateTime");
  cJSON *stations=get(temp,"data"),*item=nullptr;bool found=false;
  cJSON_ArrayForEach(item,stations){cJSON *name=get(item,"place"),*unit=get(item,"unit");
   if(cJSON_IsString(name) && strcmp(name->valuestring,weather_prefs::STATIONS[station].name)==0){
    found=cJSON_IsString(unit) && strcmp(unit->valuestring,"C")==0 && fieldNumber(get(item,"value"),-20,60,out.temperature);break;}}
  cJSON *h=cJSON_GetArrayItem(get(humidity,"data"),0),*place=get(h,"place"),*unit=get(h,"unit");
  float icon=0;bool humid=cJSON_IsString(place) && strcmp(place->valuestring,"香港天文台")==0 && cJSON_IsString(unit) && strcmp(unit->valuestring,"percent")==0 && fieldNumber(get(h,"value"),0,100,out.humidity);
  bool iconOkay=fieldNumber(cJSON_GetArrayItem(get(root,"icon"),0),50,99,icon) && icon==int(icon);
  if(found && humid && iconOkay && cJSON_IsString(times) && timestamp(times->valuestring,out.reportEpoch)) {
   time_t now=time(nullptr);if(out.reportEpoch<=now+600){strcpy(out.reportTime,times->valuestring);out.icon=int(icon);auto iconTime=get(root,"iconUpdateTime");time_t iconEpoch=0;if(cJSON_IsString(iconTime)&&timestamp(iconTime->valuestring,iconEpoch)&&iconEpoch<=now+600)strcpy(out.iconTime,iconTime->valuestring);ok=true;}}
  cJSON_Delete(root);return ok;
 }
 static bool parseForecast(char *body,size_t length,ForecastSnapshot &out){
  cJSON *root=document(body,length);if(!root)return false;
  auto get=[](cJSON *p,const char *key){return cJSON_GetObjectItemCaseSensitive(p,key);};
  time_t now=time(nullptr);cJSON *updated=get(root,"updateTime"),*list=get(root,"weatherForecast"),*item=nullptr;
  bool ok=cJSON_IsString(updated)&&timestamp(updated->valuestring,out.reportEpoch)&&out.reportEpoch<=now+600&&cJSON_IsArray(list)&&cJSON_GetArraySize(list)<=9;
  bool found[2]={};uint32_t wanted[2]={dateKey(now,1),dateKey(now,2)};
  if(ok)cJSON_ArrayForEach(item,list){auto date=get(item,"forecastDate");if(!cJSON_IsString(date))continue;
   for(unsigned i=0;i<2;++i){char key[12];snprintf(key,sizeof(key),"%08u",unsigned(wanted[i]));if(strcmp(key,date->valuestring))continue;
    auto low=get(item,"forecastMintemp"),high=get(item,"forecastMaxtemp"),lu=get(low,"unit"),hu=get(high,"unit");float icon=0;auto &d=out.days[i];
    bool numeric=fieldNumber(get(item,"ForecastIcon"),50,93,icon)&&icon==int(icon);
    int code=int(icon);bool known=numeric&&((code>=50&&code<=54)||(code>=60&&code<=65)||(code>=70&&code<=77)||(code>=80&&code<=85)||(code>=90&&code<=93));
    if(found[i]||!known||!cJSON_IsString(lu)||strcmp(lu->valuestring,"C")||!cJSON_IsString(hu)||strcmp(hu->valuestring,"C")||!fieldNumber(get(low,"value"),-20,60,d.low)||!fieldNumber(get(high,"value"),-20,60,d.high)||d.low>d.high){ok=false;break;}
    d.date=wanted[i];d.icon=code;found[i]=true;
   }if(!ok)break;
  }
  ok=ok&&found[0]&&found[1];if(ok)strcpy(out.reportTime,updated->valuestring);cJSON_Delete(root);return ok;
 }
 bool download(int station,Snapshot *current,ForecastSnapshot *forecast) {
  char *error=forecast?forecast->error:current->error;
  NetworkClientSecure client;client.setCACert(HKO_ROOT_CA);client.setHandshakeTimeout(4);
  HTTPClient http;http.setReuse(false);http.setConnectTimeout(4000);http.setTimeout(1500);http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS);
  const char *url=forecast?"https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=fnd&lang=tc":"https://data.weather.gov.hk/weatherAPI/opendata/weather.php?dataType=rhrread&lang=tc";
  if(!http.begin(client,url)){strcpy(error,"HTTP_BEGIN");return false;}
  http.addHeader("Accept","application/json");int code=http.GET();
  if(code!=200){snprintf(error,32,"HTTP_%d",code);http.end();return false;}
  int size=http.getSize();if(size>8192 || size==0){strcpy(error,"BODY_SIZE");http.end();return false;}
  char *body=static_cast<char*>(malloc(8193));if(!body){strcpy(error,"BODY_MEMORY");http.end();return false;}body[0]=0;
  BodySink sink(body);int copied=http.writeToStream(&sink);http.end();client.stop(); // Release TLS buffers before parsing JSON.
  bool okay=copied>0 && !sink.failed && (size<0 || sink.count==size) && (forecast?parseForecast(body,sink.count,*forecast):parse(body,sink.count,station,*current));
  if(!okay)strcpy(error,sink.failed?"BODY_LIMIT_TIMEOUT":"JSON_OR_FIELDS");free(body);return okay;
 }
 static void worker(void *context) {
  auto &w=*static_cast<WeatherService*>(context);
  for(;;){ulTaskNotifyTake(pdTRUE,portMAX_DELAY);int station=w.requestedStation.load();int job=w.requestedJob.load();desk::Gate gate;if(!gate.held){w.retryJob.store(job);w.fetching.store(false);continue;}
   if(job==2){auto f=w.forecastSnapshot();f.status=Status::Fetching;f.error[0]=0;w.publishForecast(f);ForecastSnapshot candidate;
    bool okay=w.allowed.load()&&w.download(0,nullptr,&candidate);if(okay){f=candidate;f.valid=true;}else strcpy(f.error,candidate.error[0]?candidate.error:"OFFLINE");
    f.status=okay?Status::Ready:Status::Error;w.publishForecast(f);
    Serial.printf("FORECAST_FETCH result=%s updated=%s error=%s stack_free=%u free=%u minimum=%u largest=%u\n",okay?"PASS":"FAIL",f.reportTime,f.error,unsigned(uxTaskGetStackHighWaterMark(nullptr)),unsigned(ESP.getFreeHeap()),unsigned(ESP.getMinFreeHeap()),unsigned(heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)));
    w.fetching.store(false);continue;
   }
   if(job!=1){if(w.allowed.load())w.extras.run(job,station);w.fetching.store(false);continue;}Snapshot s=w.snapshot();
   s.station=station;s.status=Status::Fetching;s.error[0]=0;w.publish(s);
   Snapshot candidate;candidate.station=station;bool okay=w.allowed.load() && w.download(station,&candidate,nullptr);
   if(okay){s=candidate;s.valid=true;}else{strcpy(s.error,candidate.error[0]?candidate.error:"OFFLINE");}
   if(station==weather_prefs::selected().load()) {s.status=okay?Status::Ready:Status::Error;w.publish(s);}
   Serial.printf("WEATHER_FETCH result=%s station=%s updated=%s error=%s stack_free=%u free=%u minimum=%u largest=%u\n",okay?"PASS":"FAIL",weather_prefs::STATIONS[station].id,s.reportTime,s.error,unsigned(uxTaskGetStackHighWaterMark(nullptr)),unsigned(ESP.getFreeHeap()),unsigned(ESP.getMinFreeHeap()),unsigned(heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)));
   w.fetching.store(false);
  }
 }
};
